<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Patient Certificate</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .section {
            margin-bottom: 15px;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <div class="card">
            <div class="card-body">
                <div class="header">
                    <h1>BSKY</h1>
                </div>
                <div class="content">
                    <div class="section row">
                        <div class="col">
                            <strong>Admission Date:</strong> {{ $patientDetail->Admission_Date }}
                        </div>
                        <div class="col">
                            <strong>Discharge Date:</strong> {{ $patientDetail->Discharge_Date }}
                        </div>
                    </div>
                    <div class="section row">
                        <div class="col">
                            <strong>Hospital Code:</strong> {{ $patientDetail->Hosp_ID }}
                        </div>
                        <div class="col">
                            <strong>Hospital Name:</strong> {{ $patientDetail->Hosp_Name }}
                        </div>
                    </div>
                    <div class="section row">
                        <div class="col">
                            <strong>Doctor Code:</strong> {{ $patientDetail->Doct_ID }}
                        </div>
                        <div class="col">
                            <strong>Doctor Name:</strong> {{ $patientDetail->Doct_Name }}
                        </div>
                    </div>
                    <div class="section row">
                        <div class="col">
                            <strong>Patient Code:</strong> {{ $patientDetail->Patient_ID }}
                        </div>
                        <div class="col">
                            <strong>Patient Name:</strong> {{ $patientDetail->Patient_Name }}
                        </div>
                    </div>
                    <div class="section">
                        <strong>Total Expenses:</strong> {{ $patientDetail->Total_Expenses }}<br>
                        <strong>Insured Amount:</strong> {{ $patientDetail->Insured_amount }}<br>
                        <strong>Total Payable Amount:</strong> {{ $patientDetail->Total_Payble_Amount }}
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

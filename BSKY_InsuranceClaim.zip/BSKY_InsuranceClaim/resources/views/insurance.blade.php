<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Insurance Claim </title>
     <!-- Bootstrap CSS -->
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .hidden-border {
            border: none;
            background-color: transparent;
        }
        .custom-card {
            width: 80%;
            
        }
        
    </style>
</head>
<body>
    
    <div class="container d-flex justify-content-center">
        <div class="card custom-card">
            <div class="card-body">
                <h1 class="card-title text-center">Insurance Claim</h1>
                <form action="saveData" method="post">
                    @csrf
                    <div class="form-group">
                        <label for="hospital">Select Hospital :</label>
                        <select class="form-control" name="hospital" id="hospital">
                            <option value="">--choose--</option>
                            @if (!empty($hospitals))
                                @foreach($hospitals as $hospital)
                                    <option value="{{ $hospital->Hosp_ID }}">{{ $hospital->Hosp_Name }}</option>
                                @endforeach
                            @endif
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="doctor">Select Doctor :</label>
                        <select class="form-control" name="doctor" id="doctor">
                           
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="patient">Select Patient :</label>
                        <select class="form-control" name="patient" id="patient">
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="form-group col-md-6 d-flex align-items-center">
                            <label for="insurance" class="mr-2">Insurance Name:</label>
                            <input type="text" class="form-control hidden-border" id="insurance" name="insurance" readonly>
                        </div>
                        <div class="form-group col-md-6 d-flex align-items-center">
                            <label for="scheme" class="mr-2">Scheme Name:</label>
                            <input type="text" class="form-control hidden-border" id="scheme" name="scheme" readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="admissionDate">Select Admission Date :</label>
                        <input type="date" class="form-control" name="admissionDate" id="admissionDate">
                    </div>
                    <div class="form-group">
                        <label for="dischargeDate">Select Discharge Date :</label>
                        <input type="date" class="form-control" name="dischargeDate" id="dischargeDate">
                    </div>
                    <div class="form-group">
                        <label for="totalExpenses">Enter Total Expenses :</label>
                        <input type="text" class="form-control" name="totalExpenses" id="totalExpenses">
                    </div>
                    <center>
                        <button type="submit" class="btn btn-danger">Save</button>
                    </center>
                </form>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="{{ URL::asset('js/jquery.js') }}"></script>
    <script type="text/javascript">
        $(document).ready(function() {
             // Function to set the default dates and constraints
            function setDateConstraints() {
                var currentDate = new Date();
                var admissionDate = new Date();
                admissionDate.setDate(currentDate.getDate() - 15);

                var formattedCurrentDate = currentDate.toISOString().split('T')[0];
                var formattedAdmissionDate = admissionDate.toISOString().split('T')[0];

                $('#admissionDate').val(formattedAdmissionDate);
                $('#admissionDate').attr('max', formattedCurrentDate);

                $('#dischargeDate').attr('min', formattedAdmissionDate);
                $('#dischargeDate').attr('max', formattedCurrentDate);
            }

            // Set the initial date constraints
            setDateConstraints();


            $("#hospital").change(function() {
                var hospitalId = $(this).val();
                if (hospitalId !== '') {
                    // AJAX request to fetch doctors for the selected hospital
                    $.ajax({
                        url: 'SelectDoctor',
                        type: 'get',
                        dataType: 'json',
                        data: {
                            hospitalId: hospitalId
                        },
                        success: function(res) {
                            var op = '<option value="">--Choose--</option>';
                            res.forEach(function(element) {
                                op += '<option value="' + element.Doct_ID + '">' + element.Doct_Name + '</option>';
                            });
                            $('#doctor').html(op);
                            // Reset patient and insurance details
                            $('#patient').html('<option value="">--Choose--</option>');
                            $('#insurance').val('');
                            $('#scheme').val('');
                        }
                    });
                } else {
                    // Reset doctor, patient, and insurance details if no hospital is selected
                    $('#doctor').html('<option value="">--Choose--</option>');
                    $('#patient').html('<option value="">--Choose--</option>');
                    $('#insurance').val('');
                    $('#scheme').val('');
                }
            });

            $("#doctor").change(function() {
                var doctorId = $(this).val();
                if (doctorId !== '') {
                    // AJAX request to fetch patients for the selected doctor
                    $.ajax({
                        url: 'SelectPatient',
                        type: 'get',
                        dataType: 'json',
                        data: {
                            doctorId: doctorId
                        },
                        success: function(res) {
                            var op = '<option value="">--Choose--</option>';
                            res.forEach(function(element) {
                                op += '<option value="' + element.Patient_ID + '">' + element.Patient_Name + '</option>';
                            });
                            $('#patient').html(op);
                            // Reset insurance details
                            $('#insurance').val('');
                            $('#scheme').val('');
                        }
                    });
                } else {
                    // Reset patient and insurance details if no doctor is selected
                    $('#patient').html('<option value="">--Choose--</option>');
                    $('#insurance').val('');
                    $('#scheme').val('');
                }
            });

            $("#patient").change(function() {
                var patientId = $(this).val();
                if (patientId !== '') {
                    // AJAX request to fetch insurance details for the selected patient
                    $.ajax({
                        url: 'SelectInsuranceScheme',
                        type: 'get',
                        dataType: 'json',
                        data: {
                            patientId: patientId
                        },
                        success: function(res) {
                            $('#insurance').val(res.Insurance_Name);
                            $('#scheme').val(res.Insurance_Scheme_Name);
                        }
                    });
                } else {
                    // Reset insurance details if no patient is selected
                    $('#insurance').val('');
                    $('#scheme').val('');
                }
            });

            // Event handler for date validation
            $('#dischargeDate').change(function() {
                var dischargeDate = new Date($(this).val());
                var admissionDate = new Date($('#admissionDate').val());
                var currentDate = new Date();

                if (dischargeDate < admissionDate || dischargeDate > currentDate) {
                    alert("Discharge date must be greater than the admission date and less than the current date.");
                    $(this).val('');
                }
            });
        });
    </script>

   <div class="mt-5">
            <h2>Patient Details</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sl No</th>
                        <th>Doctor Name</th>
                        <th>Patient Name</th>
                        <th>Insurance Name</th>
                        <th>Insurance Scheme Name</th>
                        <th>Admission Date</th>
                        <th>Discharge Date</th>
                        <th>Total Expenses</th>
                        <th>Insured Amount</th>
                        <th>Total Payable</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($patientDetails as $index => $detail)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>{{ $detail->Doct_Name }}</td>
                            <td>{{ $detail->Patient_Name }}</td>
                            <td>{{ $detail->Insurance_Name }}</td>
                            <td>{{ $detail->Insurance_Scheme_Name }}</td>
                            <td>{{ $detail->Admission_Date }}</td>
                            <td>{{ $detail->Discharge_Date }}</td>
                            <td>{{ $detail->Total_Expenses }}</td>
                            <td>{{ $detail->Insured_amount }}</td>
                            <td>{{ $detail->Total_Payble_Amount }}</td>
                             <td><a href="{{ url('/generateCertificate/' . $detail->Patient_ID) }}">Certificate</a></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
                        

    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

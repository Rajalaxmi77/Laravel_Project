<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\InsuranceController;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/insurance', function () {
    return view('insurance');
});
Route::get('/insurance',[InsuranceController::class,'index']);
Route::get('/SelectDoctor',[InsuranceController::class,'getDoctor']);
Route::get('/SelectPatient',[InsuranceController::class,'getPatient']);
Route::get('/SelectInsuranceScheme', [InsuranceController::class, 'getInsuranceScheme']);
Route::post('/saveData',[InsuranceController::class,'store']);
Route::get('/generateCertificate/{patientId}', [InsuranceController::class, 'generateCertificate']);

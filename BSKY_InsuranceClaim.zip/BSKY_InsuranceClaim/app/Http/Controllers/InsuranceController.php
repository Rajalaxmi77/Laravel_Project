<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class InsuranceController extends Controller
{
    public function index()
    {
        // Fetch hospitals for dropdown
        $hospitals = DB::table('tbl_hospital')->get();
        //dd($hospital);
        $patientDetails = DB::table('tbl_patient_details as pd')
            ->join('tbl_patient as p', 'pd.Patient_ID', '=', 'p.Patient_ID')
            ->join('tbl_doctor as d', 'p.Doct_ID', '=', 'd.Doct_ID')
            ->join('tbl_insurance_scheme as is', 'p.Insurance_Scheme_ID', '=', 'is.Insurance_Scheme_ID')
            ->join('tbl_insurance as i', 'is.Insurance_ID', '=', 'i.Insurance_ID')
            ->select('pd.*', 'p.Patient_Name', 'd.Doct_Name', 'i.Insurance_Name', 'is.Insurance_Scheme_Name')
            ->get();
       
        return view('insurance', ['hospitals' => $hospitals,'patientDetails' => $patientDetails]);
    }
    public function getDoctor(Request $request)
    {
        $hospitalId = $request->hospitalId;
        
        $res = DB::table('tbl_Doctor')
            ->where('Hosp_ID', $hospitalId)
            ->select('Doct_ID', 'Doct_Name')
            ->get();
        
        return response()->json($res);
        //dd($res);

    }
    public function getPatient(Request $request)
    {
        $doctorId = $request->doctorId;
        
        $res = DB::table('tbl_Patient')
            ->where('Doct_ID', $doctorId)
            ->select('Patient_ID', 'Patient_Name')
            ->get();
        
        return response()->json($res);
        //dd($res);

    }

    public function getInsuranceScheme(Request $request)
    {
        $patientId = $request->patientId;

        $result = DB::table('tbl_Patient')
            ->join('tbl_Insurance_Scheme', 'tbl_Patient.Insurance_Scheme_ID', '=', 'tbl_Insurance_Scheme.Insurance_Scheme_ID')
            ->join('tbl_Insurance', 'tbl_Insurance_Scheme.Insurance_ID', '=', 'tbl_Insurance.Insurance_ID')
            ->where('tbl_Patient.Patient_ID', $patientId)
            ->select('tbl_Insurance.Insurance_Name', 'tbl_Insurance_Scheme.Insurance_Scheme_Name')
            ->first();

        return response()->json($result);
        //dd($result);
    }

    public function store(Request $request)
    {
        // Validate incoming request data
        $validatedData = $request->validate([
            'doctor' => 'required|integer',
            'patient' => 'required|integer',
            'admissionDate' => 'required|date',
            'dischargeDate' => 'required|date|after:admissionDate',
            'totalExpenses' => 'required|numeric',
        ]);

        $doctorId = $request->input('doctor');
        $patientId = $request->input('patient');
        $admissionDate = $request->input('admissionDate');
        $dischargeDate = $request->input('dischargeDate');
        $totalExpenses = $request->input('totalExpenses');

        // Fetch insurance scheme details for the patient
        $insuranceScheme = DB::table('tbl_patient')
            ->join('tbl_insurance_scheme', 'tbl_patient.Insurance_Scheme_ID', '=', 'tbl_insurance_scheme.Insurance_Scheme_ID')
            ->join('tbl_insurance', 'tbl_insurance_scheme.Insurance_ID', '=', 'tbl_insurance.Insurance_ID')
            ->where('tbl_patient.Patient_ID', $patientId)
            ->select('tbl_insurance.Insurance_Name', 'tbl_insurance_scheme.Insurance_Scheme_Name', 'tbl_insurance_scheme.Insurance_Percentage_cover')
            ->first();

        // Calculate insured amount
        $insurancePercentage = $insuranceScheme->Insurance_Percentage_cover / 100;
        $insuredAmount = $totalExpenses * $insurancePercentage;
        $payableAmount = $totalExpenses - $insuredAmount;

        // Save patient details to tbl_Patient_Details
        DB::table('tbl_patient_details')->insert([
            'Patient_ID' => $patientId,
            'Admission_Date' => $admissionDate,
            'Discharge_Date' => $dischargeDate,
            'Total_Expenses' => $totalExpenses,
            'Insured_Amount' => $insuredAmount,
            'Total_Payble_Amount' => $payableAmount,
        ]);

        // Optionally, you can redirect to a success page or return a response
        return redirect()->back()->with('success', 'Patient details saved successfully.');
    }

    public function generateCertificate($patientId)
    {
        // Fetch patient details
        $patientDetail = DB::table('tbl_patient_details as pd')
            ->join('tbl_patient as p', 'pd.Patient_ID', '=', 'p.Patient_ID')
            ->join('tbl_doctor as d', 'p.Doct_ID', '=', 'd.Doct_ID')
            ->join('tbl_insurance_scheme as is', 'p.Insurance_Scheme_ID', '=', 'is.Insurance_Scheme_ID')
            ->join('tbl_insurance as i', 'is.Insurance_ID', '=', 'i.Insurance_ID')
            ->join('tbl_hospital as h', 'd.Hosp_ID', '=', 'h.Hosp_ID')
            ->select('pd.*', 'p.Patient_Name', 'd.Doct_Name', 'd.Doct_ID', 'i.Insurance_Name', 'is.Insurance_Scheme_Name', 'is.Insurance_Percentage_cover', 'h.Hosp_Name', 'h.Hosp_ID')
            ->where('p.Patient_ID', $patientId)
            ->first();

        // Generate PDF
        $pdf = Pdf::loadView('certificate', compact('patientDetail'));

        // Download PDF
        return $pdf->download('certificate.pdf');
    }
}

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Patient Medical History</title>
    <style>
    #field {
        width: 99%;
        background-color: #F8F8FF;
    }

    b {
        font-size: 40px;
    }

    p {
        font-size: 20px;
    }
    </style>
</head>

<body>
    <?php if(count($data) > 0): ?>
    <div style="position: relative;">
        <fieldset id="field">

            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRcSreEFq7xCYayviQv93D0cN95U3aCYY5EjZUTJvCTA&s"
                alt="Clinic Logo" style="max-width: 300px; max-height: 300px; position: absolute; top: 0; left: 0;">

            <header>
                <center>
                    <pre>
                        <b> Patient Medical History  </b> <br>
                       <p> NAME- <?php echo e($data[0]->PatientName); ?>

    AGE- <?php echo e($data[0]->Age); ?>        GENDER-<?php echo e($data[0]->Gender); ?>

                        </p>
                    </pre>
                </center>
            </header>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <fieldset>
                <legend align="left"><?php echo e($view->DateOfVisit); ?></legend>
                disease Name:<?php echo e($view->DiseaseName); ?> <br>
                prescription Details:<?php echo e($view->PrescriptionDetails); ?>

            </fieldset>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <center>
                // END OF REOPERT //
            </center>
        </fieldset>

        <?php endif; ?>

    </div>

</body>



</html><?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\doctor'sPen9\resources\views/viewhistory.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor's Pen</title>
    <style>
        /* Add some basic styling for better visualization */
        label {
            display: inline-block;
            width: 150px; /* Adjust as needed */
            color: orange; /* Set label color to orange */
        }
        input {
            width: 200px; /* Adjust as needed */
            margin-bottom: 10px;
        }
        .form-group {
            display: inline-block;
            margin-right: 20px;
        }
    </style>
</head>
<body>
    <div>
        <center><h1>Doctor's Pen</h1>
        <form action="" method="get">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                Patient's Phone No*:<br>
                <input type="text" name="phone" id="phone" required>
            </div>
            <button type="submit" id="btn">Search</button>
    </form>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#btn").click(function(e){
                e.preventDefault();
                $.ajax({
                    url:"getdetails",
                    type:"get",
                    dataType:"JSON",
                    data:{phone:$("#phone").val()},
                    success:function(res){
                        json_text=JSON.stringify(res);
                        obj=JSON.parse(json_text);
                        $("#pname").val(obj.patient_name);
                        $("#phoneid").val(obj.phone_no);
                        $("#gender").val(obj.gender);
                        $("#dob").val(obj.dob);
                        $("#pid").val(obj.patient_id);

                        
                    }
                })
            })
        })
    </script>
       
        </center>
        
       <div>
    <form action="savedata" method="post">
        <?php echo csrf_field(); ?>
        <fieldset>
            <legend><h1>Patient's Details</h1></legend>
            
            <div class="form-group">
                <label for="pname">Patient Name:</label>
                <br>
                <input type="text" name="pname" id="pname">
                <input type="hidden" name="pid" id="pid">
            </div>
            <div class="form-group">
                <label for="phone">Phone No:</label>
                <br>
                <input type="text" name="phoneid" id="phoneid">
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label>
                <br>
                <input type="text" name="gender" id="gender">
            </div>
            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <br>
                <input type="text" name="dob" id="dob">
            </div>
            <div class="form-group">
                <label for="history">Patient History:</label>
                <br>
                <a href="medicalhistory">view</a>
            </div>
        </fieldset>
    
</div>

<fieldset>
            <legend><h1>Add Prescription Details</h1></legend>

            <div class="form-group">
                <label for="doctor">Doctor Name:</label>
                <br>
                <input type="text" name="dname" id="dname">
            </div>
            <div class="form-group">
                <label for="dov">Date of visit:</label>
                <br>
                <input type="date" name="dov" id="dov">
            </div>
            <div class="form-group">
                <label for="disease">Disease Name:</label>
                <br>
                <select name="disease" id="disease">
                    <option value="" hidden="hidden">select &nbsp;&nbsp;&nbsp;</option>
                    <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r->disease_id); ?>"><?php echo e($r->disease_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="pdetails">Prescription Details:</label>
                <br>
                <textarea name="pdetails" id="pdetails" cols="50" rows="3"></textarea>
            </div>

            <br>
            <center><button type="submit">Save</button></center>
        </fieldset>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\doctor'sPen\resources\views/doctorspen.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor's Pen</title>
    <style>
        /* Add some basic styling for better visualization */
        label {
            display: inline-block;
            width: 150px; /* Adjust as needed */
            color: orange; /* Set label color to orange */
        }
       input {
            width: 200px; /* Adjust as needed */
            margin-bottom: 10px;
        }
        .form-group {
            display: inline-block;
            margin-right: 20px;
        }
        .mandatory-label {
            position: absolute;
            right: 20px; /* Adjust the right position as needed */
            
        }

        fieldset {

            padding-bottom: 70px; /* Add padding to the fieldset */
            padding-left: 70px; /* Add padding to the fieldset */
            margin-right: 50px; /* Add margin to the fieldset */
            margin-left: 50px; /* Add margin to the fieldset */
            margin-bottom: 30px; /* Add margin to the fieldset */
        }
    </style>
</head>
<body>
    <div>
        <center><h1>Doctor's Pen</h1>
            <form action="" method="get">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    Patient's Phone No*:<br>
                    <input type="text" name="phone" id="phone" required>
                </div>
                <button type="submit" id="btn">Search</button>
            </form>
        </center>
        
       <div>
        <form action="savedata" method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <legend><h1>Patient's Details</h1></legend>
                
                <div class="form-group">
                    <label for="pname">Patient Name:</label>
                    <br>
                    <input type="text" name="pname" id="pname" disabled>
                    <input type="hidden" name="pid" id="pid">
                </div>
                <div class="form-group">
                    <label for="phone">Phone No:</label>
                    <br>
                    <input type="text" name="phoneid" id="phoneid" disabled>
                </div>
                <div class="form-group">
                    <label for="gender">Gender:</label>
                    <br>
                    <input type="text" name="gender" id="gender" disabled>
                </div>
                <div class="form-group">
                    <label for="dob">Date of Birth:</label>
                    <br>
                    <input type="text" name="dob" id="dob" disabled>
                </div>
                <div class="form-group">
                    <label for="history">Patient History:</label>
                    <br>
                    <a href="viewData" id="view">view</a>
                </div>
            </fieldset>
        
       </div>
    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#btn").click(function(e){
                e.preventDefault();
                $.ajax({
                    url:"getdetails",
                    type:"get",
                    dataType:"JSON",
                    data:{phone:$("#phone").val()},
                    success:function(res){
                        json_text=JSON.stringify(res);
                        obj=JSON.parse(json_text);
                        $("#pname").val(obj.patient_name);
                        $("#phoneid").val(obj.phone_no);
                        $("#gender").val(obj.gender);
                        $("#dob").val(obj.dob);
                        $("#pid").val(obj.patient_id);  
                    }
                })
            })
            $("#view").click(function(e){
                e.preventDefault();
                var patientid=$('#pid').val();
                //console.log(patientid);
                window.location.href="viewData?patientid=" + patientid;
            }); 
        })
       
    </script>

        <label for="" class="mandatory-label">* mandetory fields</label>

        <fieldset>
            <legend><h1>Add Prescription Details</h1></legend>

                <div class="form-group">
                    <input type="hidden" name="dname" id="dname" value="Dr.Amit Singh">
                </div>
                <div class="form-group">
                    <input type="hidden" name="dov" id="dov" value="<?= date('Y-m-d'); ?>">
                </div>
                <center>
                <div class="form-group">
                    <label for="disease">Disease Name:</label>
                    <br>
                    <select name="disease" id="disease">
                        <option value="" hidden="hidden">select &nbsp;&nbsp;&nbsp;</option>
                        <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($r->disease_id); ?>"><?php echo e($r->disease_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="pdetails">Prescription Details:</label>
                    <br>
                    <br>
                    <textarea name="pdetails" id="pdetails" cols="50" rows="3"></textarea>
                </div>
                </center>

                <br>
                <br>
            <center><button type="submit">Save</button></center>
        </fieldset>
      </form>
    </div>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\doctor'sPen9\resources\views/doctorspen.blade.php ENDPATH**/ ?>
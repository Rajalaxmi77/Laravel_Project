<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <fieldset>
        <h1>Patient's Medical History</h1>
        <table>
            <tr>
                <td>Name</td>
                <td>Gender</td>
                <td>Prescription Details</td>
            </tr>
            <?php $__currentLoopData = $res; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($r->patient_name); ?></td>
                <td><?php echo e($r->gender); ?></td>
                <td><?php echo e($r->prescription_details); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </fieldset>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\doctor'sPen\resources\views/viewhistory.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\doctorController;
use DB;

class doctorController extends Controller
{
    public function getDetails(Request $request)
    {
        $phone=$request->phone;
        $res=DB::table('patient_master')
        ->select('patient_name','phone_no','gender','dob','patient_id')
        ->where('phone_no', $phone)
        ->first();

        return response()->json($res);

    }
    public function getDisease(Request $request)
    {
        $res=DB::table('disease_master')->get();
        return view('doctorspen',['res'=>$res]);
    }

    public function saveData(Request $request)
    {
        $input=$request->all();
        DB::table('prescription_tbl')
        ->insert([
            'doctor_name'=>$input['dname'],
            'date_of_visit'=>$input['dov'],
            'patient_id' => $input['pid'],
            'disease_id' =>$input['disease'],
            'prescription_details' => $input['pdetails'],
        ]);
        return redirect('doctor');
    }
    public function viewHistory(Request $request)
    {
        $patientId = $request->input('patientid');
        // dd($patientId);
        $res = DB::table('patient_master AS pm')
        ->join('prescription_tbl AS pt', 'pm.patient_id', '=', 'pt.patient_id')
        ->join('disease_master AS dm', 'pt.disease_id', '=', 'dm.disease_id')
        ->select(
        'pm.patient_name AS PatientName',
        DB::raw('YEAR(CURDATE()) - YEAR(pm.dob) AS Age'),
        'pm.gender AS Gender',
        'dm.disease_name AS DiseaseName',
        'pt.date_of_visit AS DateOfVisit',
        'pt.prescription_details AS PrescriptionDetails'
        )
        ->where('pm.patient_id', $patientId)
        ->get();
        return view('viewhistory',['data'=>$res]);
    }

}

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Patient Medical History</title>
    <style>
    #field {
        width: 99%;
        background-color: #F8F8FF;
    }

    b {
        font-size: 40px;
    }

    p {
        font-size: 20px;
    }
    </style>
</head>

<body>
    @if(count($data) > 0)
    <div style="position: relative;">
        <fieldset id="field">

            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSRcSreEFq7xCYayviQv93D0cN95U3aCYY5EjZUTJvCTA&s"
                alt="Clinic Logo" style="max-width: 300px; max-height: 300px; position: absolute; top: 0; left: 0;">

            <header>
                <center>
                    <pre>
                        <b> Patient Medical History  </b> <br>
                       <p> NAME- {{$data[0]->PatientName}}
    AGE- {{$data[0]->Age}}        GENDER-{{ $data[0]->Gender}}
                        </p>
                    </pre>
                </center>
            </header>
            @foreach($data as $view)
            <fieldset>
                <legend align="left">{{$view->DateOfVisit}}</legend>
                disease Name:{{$view->DiseaseName}} <br>
                prescription Details:{{$view->PrescriptionDetails}}
            </fieldset>
            @endforeach
            <center>
                // END OF REOPERT //
            </center>
        </fieldset>

        @endif

    </div>

</body>



</html>
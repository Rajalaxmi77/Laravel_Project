<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor's Pen</title>
    <style>
        /* Add some basic styling for better visualization */
        label {
            display: inline-block;
            width: 150px; /* Adjust as needed */
        }
        input {
            width: 200px; /* Adjust as needed */
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div>
        <h1>Doctor's Pen</h1>
        <form action="">
            @csrf
            <div>
                <label for="phone">Patient's Phone No*:</label>
                <input type="text" name="phone" id="phone" required>
            </div>
        </form>

        <div>
            <h2>Patient's Details:</h2>
            <form action="">
                <div>
                    <label for="pname">Patient Name:</label>
                    <input type="text" name="pname" id="pname">
                </div>
                <div>
                    <label for="phone">Phone No:</label>
                    <input type="text" name="phone" id="phone">
                </div>
                <div>
                    <label for="gender">Gender:</label>
                    <input type="text" name="gender" id="gender">
                </div>
                <div>
                    <label for="dob">Date of Birth:</label>
                    <input type="text" name="dob" id="dob">
                </div>
                <div>
                    <label for="history">Patient History:</label>
                    <a href="#">view</a>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

 <!-- @foreach($res as $r)
                        <option value="{{ $r->disease_id }}">{{ $r->disease_name }}</option>
                    @endforeach -->


blade.php

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor's Pen</title>
    <style>
        /* Add some basic styling for better visualization */
        label {
            display: inline-block;
            width: 150px; /* Adjust as needed */
            color: orange; /* Set label color to orange */
        }
        input {
            width: 200px; /* Adjust as needed */
            margin-bottom: 10px;
        }
        .form-group {
            display: inline-block;
            margin-right: 20px;
        }
    </style>
</head>
<body>
    <div>
        <center><h1>Doctor's Pen</h1>
        <form action="" method="get">
            @csrf
            <div class="form-group">
                Patient's Phone No*:<br>
                <input type="text" name="phone" id="phone" required>
            </div>
            <button type="submit">Search</button>
    </form>
    
        </center>
        
        <div>
            <form action="">
            <h2>Patient's Details:</h2>
            
                <div class="form-group">
                    <label for="pname">Patient Name:</label>
                    <br>
                    <input type="text" name="pname" id="pname">
                </div>
                <div class="form-group">
                    <label for="phone">Phone No:</label>
                    <br>
                    <input type="text" name="phone" id="phone">
                </div>
                <div  class="form-group">
                    <label for="gender">Gender:</label>
                    <br>
                    <input type="text" name="gender" id="gender">
                </div>
                <div  class="form-group">
                    <label for="dob">Date of Birth:</label>
                    <br>
                    <input type="text" name="dob" id="dob">
                </div>
                <div  class="form-group">
                    <label for="history">Patient History:</label>
                    <br>
                    <a href="#">view</a>
                </div>
            
        </div>

        <h2>Add Prescription Details</h2>
            <center>
            <div  class="form-group">
                <label for="">Disease Name:</label>
                <br>
                <select name="disease" id="disease">
                    <option value="" hidden="hidden">select &nbsp;&nbsp;&nbsp;</option>
                   @foreach($res as $r)
                        <option value="{{ $r->disease_id }}">{{ $r->disease_name }}</option>
                    @endforeach
                </select>
            </div>
            <div  class="form-group">
                <label for=""> Prescription Details:</label>
                <br>
                <textarea name="pdetails" id="pdetails" cols="50" rows="3"></textarea>
            </div>

                <br>
            <button type="submit">Save</button>
            </center>
        </form>
    </div>

    <script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
    <script type="text/javascript">
        $(document).ready(function(){
    $("#phone").blur(function(){
        $.ajax({
            url: "{{ url('getdetails') }}",
            type: "get",
            dataType: "json",
            data: {phone: $("#phone").val()},
            success: function(res){
                if (res) {
                    localStorage.setItem('patientDetails', JSON.stringify(res));
                    $("#pname").val(res.patient_name);
                    $("#phone").val(res.phone_no);
                    $("#gender").val(res.gender);
                    $("#dob").val(res.dob);
                } else {
                    console.log("No data found for the given phone number.");
                }
            },
            error: function(xhr, status, error){
                console.error(xhr.responseText);
            }
        })
    });

    // Check if data is stored in local storage and populate the form on page load
    var storedData = localStorage.getItem('patientDetails');
    if (storedData) {
        var parsedData = JSON.parse(storedData);
        $("#pname").val(parsedData.patient_name);
        $("#phone").val(parsedData.phone_no);
        $("#gender").val(parsedData.gender);
        $("#dob").val(parsedData.dob);
    }
});
</script>
       
</body>
</html>


 <!-- Name-
    @foreach($res as $r)
        <option value="{{ $r->patient_id }}">{{ $r->patient_name }}</option><br>
        
        <option value="{{ $r->gender }}">{{ $r->gender }}</option>
        

    @endforeach -->


    <!-- public function viewHistory(Request $request)
    {
        $phone = $request->input('phone'); // Get the phone number from the request

        // Add a condition to filter by phone number if it's provided
        $query = DB::table('prescription_tbl as pt')
            ->join('patient_master as pm', 'pt.patient_id', '=', 'pm.patient_id')
            ->select(
                'pm.patient_name',
                'pm.gender',
                'pt.prescription_details'
            );

        if ($phone) {
            $query->where('pm.phone_no', $phone); // Filter by phone number
        }

        $res = $query->get();

        return view('viewhistory', ['res' => $res, 'phone' => $phone]);
    } -->

<?php
$sl_name=1;
?>
<table border="1">
    <thead>
        <tr>
           <th>Sl NO</th>
            <th>season id</th>
            <th>crop Name</th>
            <th>farmer name</th>
            <th>adhar no</th>
            <th>father name</th>
            <th>complete address</th>
            <th>farmer category</th>
        </tr>
    </thead>
    <?php if(!empty($users)): ?>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($sl_name++); ?></td>
        <td><?php echo e($r->season == 1 ? 'Kharif' : 'Rabi'); ?></td>
        <td><?php echo e($r->crop_name); ?></td>
        <td><?php echo e($r->name); ?></td>
        <td><?php echo e($r->adhar); ?></td>
        <td><?php echo e($r->fathername); ?></td>
        <td><?php echo e($r->address); ?></td>
        <td><?php echo e($r->category); ?></td>
        
        
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table><?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\CropInsuranceApplication\resources\views/farmer.blade.php ENDPATH**/ ?>
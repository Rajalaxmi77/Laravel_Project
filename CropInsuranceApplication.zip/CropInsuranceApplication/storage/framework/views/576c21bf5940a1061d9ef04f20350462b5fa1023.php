<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        h1 {
            text-align: center;
            color: #333;
        }

        form {
            max-width: 600px;
            margin: 20px auto;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        label {
            display: block;
            margin-bottom: 8px;
        }

        select,
        input[type="text"],
        textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        input[type="radio"] {
            margin-right: 5px;
        }

        button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button[type="reset"] {
            background-color: #ccc;
            margin-left: 10px;
        }

        button a {
            text-decoration: none;
            color: #333;
        }

        button:hover,
        button[type="reset"]:hover {
            background-color: #45a049;
        }

        .error-message {
            color: red;
        }
    </style> -->
    
</head>

<body>
    <h1>Crop Insurance Application Form</h1>
    <form action="savedata" method="post"  onsubmit="return validateForm()">
    <?php echo csrf_field(); ?>
    Season : <select name="seasonname" id="seasonid">
        <option value="" hidden="hidden">choose...</option>
        <option value="1" name="kharif">Kharif</option>
        <option value="2" name="rabi">Rabi</option>
    </select><br><br>
    Crop Name : <select name="cropname" id="cropid">
        <input type="hidden" >

    </select><br><br>
    <label for="">Farmer Name:</label>
    <input type="text" name="farmer" id="farmer">
    <br><br>
    <label for="">Adhar Number:</label>
    <input type="text" name="adhar" id="adhar"><br><br>
    <label for="">Father Name:</label>
    <input type="text" name="fname" id="fname"><br><br>
    <label for="">Complete Address:</label>
    <textarea name="address" id="address" cols="30" rows="10"></textarea><br>
    <label for="">Farmer Category:</label>
    <input type="radio" name="category" value="small">Small
    <input type="radio" name="category" value="medium">medium
    <input type="radio" name="category" value="large">large
    <br>
    <br>
    <button type="submit">Submit</button>
    <button type="submit"><a href="crop"></a>Clear</button>

</form>
<script>
    function validateForm() {
        var season = document.getElementById('seasonid').value;
        var crop = document.getElementById('cropid').value;
        var farmer = document.getElementById('farmer').value.trim();
        var adhar = document.getElementById('adhar').value.trim();
        var fname = document.getElementById('fname').value.trim();
        var address = document.getElementById('address').value.trim();
        var category = document.querySelector('input[name="category"]:checked');

        if (season === '' || crop === '' || farmer === '' || adhar === '' || fname === '' || address === '' || !category) {
            alert('Please fill in all the required fields.');
            return false;
        }
        var specialCharacters = /^[a-zA-Z0-9 ]*$/; 
        if (!farmer.match(specialCharacters)) {
            alert('Farmer Name should not contain special characters.');
            return false;
        }
        if (!isNaN(farmer)) {
            alert('Name cannot be a number.');
            return false;
        }
        if (!address.match(specialCharacters)) {
            alert('Farmer Name should not contain special characters.');
            return false;
        }

        if (address.length > 250) {
            alert('maximum length should be 250 characters.');
            return false;
        }
        if (farmer.length > 50) {
            alert('Farmer Name should not exceed 50 characters.');
            return false;
        }
        if (adhar.length > 12) {
            alert('adhar No. should not exceed 12 characters.');
            return false;
        }
        if (isNaN(adhar)) {
            alert('Adhar Name cannot be a character.');
            return false;
        }
        if (fname.length > 12) {
            alert('Father Name should not exceed 12 characters.');
            return false;
        }
        var existingAdhars = ["123456789", "987654321","12345","1234567","123459"]; 
        if (existingAdhars.includes(adhar)) {
            alert('Adhar Number already exists. Please enter a different Adhar Number.');
            return false;
        }


        return true; 
    }
</script>
  
    <script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
    <script>
    $(document).ready(function() {
        $('#seasonid').change(function() {
            $.ajax({
                url: "getCrop",
                type: "get",
                dataType: "JSON",
                data: {
                    seasonid: $('#seasonid').val()
                },
                success: (res) => {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    op = "";
                    obj.forEach(obj => {
                        op = op + "<option value=" + obj.crop_id + ">" + obj
                            .crop_name + "</option>";
                    })
                    $("#cropid").html(op);
                    
                    
                }
            })
        })
    })
    </script>
</body>

</html>




<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\CropInsuranceApplication\resources\views/crop.blade.php ENDPATH**/ ?>
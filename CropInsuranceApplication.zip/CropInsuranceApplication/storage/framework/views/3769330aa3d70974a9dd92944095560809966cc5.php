<form action="" method="post">
    <?php echo csrf_field(); ?>
    <label for="season">Season:</label>
    <select name="season" id="seasonid">
        <option value="" hidden="hidden">- Select -</option>
        <option value="1" id="kharif">Kharif</option>
        <option value="2" id="rabi">Rabi</option>
    </select>
    <br><br>
    <label for="crop_id">Crop Name:</label>
        <select name="crop_id" id="crop_id">
            <option value="">- Select -</option>
        </select>
        <br><br>
    <label for="">Farmer Name:</label>
    <input type="text" name="farmer" id="farmer">
    <br><br>
    <label for="">Adhar Number:</label>
    <input type="text" name="adhar" id="adhar"><br><br>
    <label for="">Father Name:</label>
    <input type="text" name="fname" id="fname"><br><br>
    <label for="">Complete Address:</label>
    <textarea name="address" id="address" cols="30" rows="10"></textarea><br>
    <label for="">Farmer Category:</label>
    <input type="radio" name="category" value="small">Small
    <input type="radio" name="category" value="medium">medium
    <input type="radio" name="category" value="large">large
    <br>
    <br>
    <button type="submit">Submit</button>
    <button type="reset">Clear</button>

</form>

<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"> </script>
<script type="text/javascript">
$(document).ready(function() {
        $('#seasonid').change(function() {
            $.ajax({
                url: "getCrop",
                type: "get",
                dataType: "JSON",
                data: {
                    seasonid: $('#seasonid').val()
                },
                success: (res) => {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    op = "";
                    obj.forEach(obj => {
                        op = op + "<option value=" + obj.crop_id + ">" + obj
                            .crop_name + "</option>";
                    })
                    $("#crop_id").html(op);
                }
            })
        })
    })
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\CropInsuranceApplication\resources\views/application.blade.php ENDPATH**/ ?>
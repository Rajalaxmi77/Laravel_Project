<?php
$sl_name=1;
?>
<table border="1">
    <thead>
        <tr>
           <th>Sl NO</th>
            <th>season Name</th>
            <th>crop Name</th>
            <th>farmer name</th>
            <th>adhar no</th>
            <th>father name</th>
            <th>complete address</th>
            <th>farmer category</th>
        </tr>
    </thead>
    @if (!empty($users))
    @foreach($users as $r)
    <tr>
        <td>{{$sl_name++}}</td>
        <td>{{ $r->season == 1 ? 'Kharif' : 'Rabi' }}</td>
        <td>{{$r->crop_name}}</td>
        <td>{{$r->name}}</td>
        <td>{{$r->adhar}}</td>
        <td>{{$r->fathername}}</td>
        <td>{{$r->address}}</td>
        <td>{{ $r->category }}</td>
        
        
    </tr>
    @endforeach
    @endif
</table>
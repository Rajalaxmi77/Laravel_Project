<?php

namespace App\Http\Controllers;
use App\Http\Controllers\cropController;

use DB;

use Illuminate\Http\Request;

class CropController extends Controller
{
    public function cropData(Request $request){
        $id = $request->seasonid;
        $user = DB::table('crop_details')->where('season_id', $id)->get();
        return response()->json($user);
    }
    public function savedata(Request $request){
        
        $input=$request->all();
        DB::table('farmer_details')
        ->insert([
            'name' => $input['farmer'],
            'adhar' =>$input['adhar'],
            'fathername' => $input['fname'],
            'address' => $input['address'],
            'category' => $input['category'],
            'season' => $input['seasonid'],
            'crop' => $input['cropname'],
        ]);
        $user=DB::table('farmer_details as fd')
        ->join('crop_details as cd' , 'fd.season' ,'=','cd.season_id')
        ->select(
            'cd.crop_name',
            'fd.season',
            'fd.name',
            'fd.adhar',
            'fd.fathername',
            'fd.address',
            'fd.category'

        )->get();
     return view('farmer',['users'=>$user]);

    }
    
}
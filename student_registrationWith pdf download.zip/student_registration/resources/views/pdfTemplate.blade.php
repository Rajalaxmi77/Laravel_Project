<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Name : {{ $allShowRec[0]->studentName }}</p>
    <p>DOB : {{$allShowRec[0]->studentDob}}</p>
    <p>Gender : {{$allShowRec[0]->studentGender}}</p>
</body>
</html>
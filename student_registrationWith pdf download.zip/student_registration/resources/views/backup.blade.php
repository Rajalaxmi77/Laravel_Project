<h1>Student Registration</h1>
<form id="studentForm" action="submit" method="post">
    @csrf
    Name:
    <input type="text" name="sname" id="sname" required>
    <input type="hidden" name="studentId" id="studentId">
    <br><br>
    DOB:
    <input type="date" name="dob" id="dob" required>
    <br><br>
    Gender:
    <input type="radio" name="gender" id="m" value="M" required>Male
    <input type="radio" name="gender" id="f" value="F" required>Female
    <br><br>
    <button type="submit" id="save">Submit</button>
    <button type="submit" hidden="hidden" id="update">Update</button>
</form>

<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
    <script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click', '.editusers', function(e){
            e.preventDefault();
            var stuid = $(this).data('studentid');
            $.ajax({
                url: 'editData',
                type: 'GET',
                dataType: 'JSON',
                data: {
                    stuid: stuid,
                },
                success: function(res){
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    $("#sname").val(obj.studentName);
                    $("#dob").val(obj.studentDob);
                    $("#gender").val(obj.studentGender);
                    $("#studentId").val(obj.studentId);
                    $('#update').show();
                    $('#save').hide();
                    
                }
            });
        });
        $(document).on('click', '#update', function(e){
            e.preventDefault();
            var formData = $("#studentForm").serialize();
            $.ajax({
                url: 'updateData', 
                type: 'POST',
                dataType: 'JSON',
                data: formData,
                success: function(res){
                    console.log(res);
                },
            });
        });
        
    });
</script>

<?php
if (isset($data)): ?>
<table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Dob</th>
                <th>Gender</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $d)
                <tr>
                    <td>{{$d->studentName}}</td>
                    <td>{{$d->studentDob}}</td>
                    <td>{{$d->studentGender}}</td>
                    <td>
                    <button><a href='#' class='editusers' data-studentid='{{ $d->studentId }}'>Edit</a></button>
                    <!-- | <a href='deleteusers?studentId={{$d->studentId}}'>Delete</a> -->
                    <button><a href='deleteusers?studentId={{$d->studentId}}'>Delete</a></button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <?php endif; ?>


      <!-- // $arr=$request->all();
        // DB::update('update students set studentName=?,studentDob=?,studentGender=? where studentId=?',[$arr['sname'],$arr['dob'],$arr['gender'],$arr['studentId']]); -->
    

<!-- with css -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <!-- Include Bootstrap CSS -->
    <!-- <link href="{{URL::asset('css/bootstrap.min.css')}}" rel="stylesheet"> -->
    <style>
        body {
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }

        button {
            padding: 8px 16px;
            cursor: pointer;
            color: blue;
        }

        button a {
            text-decoration: none;
            color: blue;
        }

        button:hover {
            background-color: #f2f2f2;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            box-sizing: border-box;
        }

        input[type="radio"] {
            margin-right: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Student Registration</h1>
        <form id="studentForm" action="submit" method="post">
    @csrf
    Name:
    <input type="text" name="sname" id="sname" required>
    <input type="hidden" name="studentId" id="studentId">
    <br><br>
    DOB:
    <input type="date" name="dob" id="dob" required>
    <br><br>
    Gender:
    <input type="radio" name="gender" id="m" value="M" required>Male
    <input type="radio" name="gender" id="f" value="F" required>Female
    <br><br>
    <button type="submit" id="save">Submit</button>
    <button type="submit"  id="update">Update</button>
</form>

<?php
if (isset($data)): ?>
<table border="1">
        <thead>
            <tr>
                <th>Name</th>
                <th>Dob</th>
                <th>Gender</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach($data as $d)
                <tr>
                    <td>{{$d->studentName}}</td>
                    <td>{{$d->studentDob}}</td>
                    <td>{{$d->studentGender}}</td>
                    <td>
                    <button><a href='#' class='editusers' data-studentid='{{ $d->studentId }}'>Edit</a></button>
                    <button><a href='deleteusers?studentId={{$d->studentId}}'>Delete</a></button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <?php endif; ?>
    </div>

<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
    <script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click', '.editusers', function(e){
            e.preventDefault();
            var stuid = $(this).data('studentid');
            $.ajax({
                url: 'editData',
                type: 'GET',
                dataType: 'JSON',
                data: {
                    stuid: stuid,
                },
                success: function(res){
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    $("#sname").val(obj.studentName);
                    $("#dob").val(obj.studentDob);
                    $("#gender").val(obj.studentGender);
                    $("#studentId").val(obj.studentId);
                    $('#update').show();
                    $('#save').hide(); 
                }
            });
        });
        $(document).on('click', '#update', function(e){
            e.preventDefault();
            var formData = $("#studentForm").serialize();
            $.ajax({
                url: 'updateData', 
                type: 'POST',
                dataType: 'json',
                data: formData,
                success: function(res){
                    console.log(res);
                    window.location.href = 'studentpage';
                },
            });
        });
        
    });
</script>

</body>
</html>


<!-- with ajax validation -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Student Registration</h1>
        <form id="studentForm" action="submit" method="post" novalidate>
            @csrf
            <div class="form-group">
                <label for="sname">Name:</label>
                <input type="text" class="form-control" name="sname" id="sname" required>
                <input type="hidden" name="studentId" id="studentId">
                <div class="invalid-feedback">Please enter a valid name.</div> 
            <div class="form-group">
                <label for="dob">DOB:</label>
                <input type="date" class="form-control" name="dob" id="dob" required>
                <div class="invalid-feedback">Please enter a valid date of birth.</div>
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="m" value="M" required>
                    <label class="form-check-label" for="m">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="f" value="F" required>
                    <label class="form-check-label" for="f">Female</label>
                </div>
                <div class="form-check form-check-inline">Please select a gender.</div>
            </div>
            <button type="submit" class="btn btn-primary" id="save">Submit</button>
            <button type="submit" class="btn btn-primary" id="update">Update</button>
        </form>

        <?php
        if (isset($data)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dob</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                @foreach($data as $d)
                    <tr>
                        <td>{{$d->studentName}}</td>
                        <td>{{$d->studentDob}}</td>
                        <td>{{$d->studentGender}}</td>
                        <td>
                            <button ><a href='#' class='editusers' data-studentid='{{ $d->studentId }}'>Edit</a></button>
                            <button ><a href='deleteusers?studentId={{$d->studentId}}'>Delete</a></button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    <!-- Include jQuery library -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <!-- Include Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <!-- Your custom JavaScript code here -->
    <script type="text/javascript">
         $(document).ready(function(){
        $('#studentForm').on('submit', function(event) {
             // Validate student name
            var studentName = $('#sname').val().trim();
            if (studentName === '' || !isNaN(studentName)) {
                $('#sname').addClass('is-invalid');
                $('.name-invalid-feedback').html('Please enter a valid name.');
                event.preventDefault();
                return false;
            }
            
            // Validate date of birth
            var dobValue = $('#dob').val();
            var today = new Date();
            var dob = new Date(dobValue);
            if (dob > today) {
                $('#dob').addClass('is-invalid');
                $('.dob-invalid-feedback').html('Date of birth cannot be a future date.');
                event.preventDefault();
                return false;
            }
            
            // Check overall form validity
            if (!this.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            $(this).addClass('was-validated');
        });

            $(document).on('click', '.editusers', function(e){
                e.preventDefault();
                var stuid = $(this).data('studentid');
                $.ajax({
                    url: 'editData',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        stuid: stuid,
                    },
                    success: function(res){
                        json_text = JSON.stringify(res);
                        obj = JSON.parse(json_text);
                        $("#sname").val(obj.studentName);
                        $("#dob").val(obj.studentDob);
                        $("#gender").val(obj.studentGender);
                        $("#studentId").val(obj.studentId);
                        $('#update').show();
                        $('#save').hide(); 
                    }
                });
            });

            $(document).on('click', '#update', function(e){
                e.preventDefault();
                var formData = $("#studentForm").serialize();
                $.ajax({
                    url: 'updateData', 
                    type: 'POST',
                    dataType: 'json',
                    data: formData,
                    success: function(res){
                        console.log(res);
                        window.location.href = 'studentpage';
                    },
                });
            });
        });
    </script>
</body>
</html>



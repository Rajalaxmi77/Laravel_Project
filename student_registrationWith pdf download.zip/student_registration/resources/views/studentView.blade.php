<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
       <center><h1 style="color: black;">Student Registration</h1></center>

        <a href="{{ route('download-pdf', ['id' => $allShowRec[0]->studentId]) }}" class="btn btn-primary" target="_blank">Download PDF</a>

        
    </div>

    
    
</body>
</html>

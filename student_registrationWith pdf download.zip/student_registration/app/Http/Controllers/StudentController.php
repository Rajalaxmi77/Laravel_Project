<?php

namespace App\Http\Controllers;

use App\Models\student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PDF;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //server side validation
        // $request->validate([
        // 'studentName' => ['required', 'string', 'max:50', 'regex:/^[a-zA-Z0-9\s]+$/'],
        // 'studentDob' => ['required'],
        // 'studentGender' => ['required'],
        // ]);

        // $student=new student();
        // $student->studentName=$request->sname;
        // $student->studentDob=$request->dob;
        // //$student->studentDob = date('d-m-Y', strtotime($request->dob));
        // $student->studentGender=$request->gender;
        // $student->save();

        // $lastInsertId = $student->studentId;
        $lastInsertedId = DB::table('students')->insertGetId([
            'studentName' => $request->sname,
            'studentDob' => $request->dob,
            // 'phone' => $request->gender,
            // 'date_of_birth' => $request->date_of_birth,
            'studentGender' => $request->gender,
            // 'password' => $request->password,
        ]);

        
        // return redirect('/View/' . $lastInsertedId)->with('success','Registration Successfully');

        // dd($lastInsertId);
        if($lastInsertedId){
            return redirect('studentpage/'. $lastInsertedId);
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(student $student,$id)
    {
        //dd($id);
        // $student=student::where('studentId',$id);
        $DataResQry = DB::table('students')
        ->select("*");    
        $DataResQry = $DataResQry->where('studentId',$id);
        $arrRes     = $DataResQry->get();

        $this->viewVars['allShowRec'] = $arrRes;
        return view('studentView', $this->viewVars);
        // $data=student::all();
        // return view('student',['data'=>$data]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(student $student,Request $request)
    {
        $stuid = $request->input('stuid');
        $student = student::where('studentId', $stuid)->first();
        return response()->json($student);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, student $student)
    {
        $stuid = $request->studentId;
        $data = array(
            'studentName'=> $request->sname,
            'studentDob'=> $request->dob,
            'studentGender'=> $request->gender,
        );

        $res=student::where('studentId', $stuid)->update($data); 
        return response()->json($res);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(student $student,Request $request)
    {
         $id=$request->studentId;
         $student=student::where('studentId',$id)->delete();
         return response()->json($student);
    }

    public function downloadPdf($id)
    {
        // $data = ['title' => 'Hello, this is your PDF content!'];
        $DataResQry = DB::table('students')
        ->select("*");
        $DataResQry = $DataResQry->where('studentId',$id);
        $arrRes       = $DataResQry->get();
        $this->viewVars['allShowRec'] = $arrRes;

        // dd($this->viewVars);

        $pdf = PDF::loadView('pdfTemplate', $this->viewVars);
        
        return $pdf->download('downloaded_pdf.pdf');
    }
}
// public function destroy(Request $request)
//     {
//         $studentId = $request->input('id');
//         $student = Student::where('studentId', $studentId);
//         $student->delete();
//         // return redirect('welcome');
//         if ($student) {
//             return response()->json($student);
//         }
//     }
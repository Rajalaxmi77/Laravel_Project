<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Registration</title>
    <!-- Include Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
       <center><h1 style="color: black;">Student Registration</h1></center>

        <form id="studentForm" action="submit" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="sname">Name:</label>
                <input type="text" class="form-control" name="sname" id="sname" >
                <input type="hidden" name="studentId" id="studentId">
            </div>
            <div class="form-group">
                <label for="dob">DOB:</label>
                <input type="date" class="form-control" name="dob" id="dob" >
            </div>
            <div class="form-group">
                <label for="gender">Gender:</label><br>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="m" value="M" >
                    <label class="form-check-label" for="m">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" id="f" value="F" >
                    <label class="form-check-label" for="f">Female</label>
                </div>
            </div>
            <button type="submit" class="btn btn-primary" id="save">Submit</button>
            <button type="submit" class="btn btn-primary" id="update">Update</button>
        </form>

        <?php
        if (isset($data)): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Dob</th>
                    <th>Gender</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($d->studentName); ?></td>
                        <td><?php echo e($d->studentDob); ?></td>
                        <td><?php echo e($d->studentGender); ?></td>
                        <td>
                        <button class='editusers btn btn-info' data-studentid='<?php echo e($d->studentId); ?>'>Edit</button>
                        <!-- <button class="deleteusers btn btn-success" data-studentid='<?php echo e($d->studentId); ?>'>Delete</button> -->
                    </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>

    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
   
    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"> </script>
    <script type="text/javascript">

        $(document).ready(function(){
            //var today = new Date().toISOString().split('T')[0];
        //$('input[name="dob"]').attr('max', today);

        $('#studentForm').submit(function(e) {
            e.preventDefault(); // prevent form submission

            // Validate name, gender, and DOB fields
            var name = $('input[name="sname"]').val();
            var dob = $('input[name="dob"]').val();
            var gender = $('input[name="gender"]:checked').val();

            if (name.trim() === '') {
                alert('Please enter a name.');
                return;
            }

            if (!isNaN(name.trim())) {
                alert('Name cannot be a number.');
                return;
            }

            if (/\d/.test(name.trim())) {
                alert('Name cannot contain numbers.');
                return;
            }

            if (dob.trim() === '') {
                alert('Please select a date of birth.');
                return;
            }
            // Check if DOB is not in the future
            var dobDate = new Date(dob);
            var currentDate = new Date();

            if (dobDate > currentDate) {
                alert('Date of birth cannot be in the future.');
                return;
            }

            if (!gender) {
                alert('Please select a gender.');
                return;
            }

            this.submit();
        });
    // $(document).on('click', '.deleteusers', function(e){
    //             e.preventDefault();
    //         var stuid = $(this).data('studentid');
    //         $.ajax({
    //             url: 'deleteData',
    //             type: 'GET',
    //             dataType: 'JSON',
    //             data: {
    //                 stuid: stuid,
    //             },
    //             success: function(res) {
    //                 console.log(res);
    //                 window.location.href = 'studentpage';
    //             },
    //         });
    //     });
    // });
    $(document).on('click', '.deleteusers', function(e){
            e.preventDefault();
            var stuid = $(this).data('studentid');
            var confirmation = confirm('Are you sure you want to delete this student?');
            if (confirmation) {
                $.ajax({
                    url: "deleteData",
                    type: "get",
                    data: {
                        stuid: stuid,
                    },
                    dataType: "JSON",
                    success: function(response) {
                        console.log(response);
                        location.reload();
                    },
                });
            }
        });


            $(document).on('click', '.editusers', function(e){
                e.preventDefault();
                var stuid = $(this).data('studentid');
                $.ajax({
                    url: 'editData',
                    type: 'GET',
                    dataType: 'JSON',
                    data: {
                        stuid: stuid,
                    },
                    success: function(res){
                        json_text = JSON.stringify(res);
                        obj = JSON.parse(json_text);
                        $("#sname").val(obj.studentName);
                        $("#dob").val(obj.studentDob);
                        $("#gender").val(obj.studentGender);
                        $("#studentId").val(obj.studentId);
                        $('#update').show();
                        $('#save').hide(); 
                    }
                });
            });
            $(document).on('click', '#update', function(e){
                e.preventDefault();
                var formData = $("#studentForm").serialize();
                $.ajax({
                    url: 'updateData', 
                    type: 'POST',
                    dataType: 'json',
                    data: formData,
                    success: function(res){
                        console.log(res);
                        window.location.href = 'studentpage';
                    },
                });
            });
        });
        
    </script>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\student_registration\resources\views/student.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <p>Name : <?php echo e($allShowRec[0]->studentName); ?></p>
    <p>DOB : <?php echo e($allShowRec[0]->studentDob); ?></p>
    <p>Gender : <?php echo e($allShowRec[0]->studentGender); ?></p>
</body>
</html><?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\student_registration\resources\views/pdfTemplate.blade.php ENDPATH**/ ?>
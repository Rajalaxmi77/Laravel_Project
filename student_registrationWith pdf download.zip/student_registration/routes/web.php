<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\StudentController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/studentpage', function () {
    return view('student');
});
Route::post('/submit',[StudentController::class, 'store']);
Route::get('/studentpage/{id}',[StudentController::class, 'show']);
Route::get('/deleteData',[StudentController::class, 'destroy']);
Route::get('/editData',[StudentController::class, 'edit']);
Route::post('/updateData', [StudentController::class, 'update'])->name('update');
Route::get('/download-pdf/{id}', [StudentController::class, 'downloadPdf'])->name('download-pdf');


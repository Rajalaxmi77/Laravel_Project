<script src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
<script>
$(document).ready(function() {
            $.ajax({
            url: "getBlock",
            type: "GET",
            dataType: "JSON",
            data: {},
            success: (res) => {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                op = "";
                obj.forEach(obj => {
                    op = op + "<option value=" + obj.blockid + ">" + obj
                        .blockname + "</option>";
                })
                $("#blockid").html(op);
        }
        })
        $('#blockid').change(function() {
        $.ajax({
            url:"getPanchayat",
            type:"GET",
            dataType:"JSON",
            data:{blockid: $('#blockid').val()},
            success: (res) => {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                op = "";
                obj.forEach(obj => {
                    op = op + "<option value=" + obj.panchayatid + ">" + obj
                        .panchayatname + "</option>";
                })
                $("#pid").html(op);
            }

        })
    })
})

</script>
<form action="submit" method="post">
    <?php echo csrf_field(); ?>
    Village Name:
    <input type="text" name="villagename" id="villageid"><br>
    <br>
    Total Population:
    <input type="text" name="tpname" id="tpid"><br>
    <br>
    Block :
    <select name="blockname" id="blockid">
        <option value="" >choose</option>
    </select><br>
    <br>
    Panchayat:
    <select name="pname" id="pid">
    </select>
    <br>
    <br>
    
    <input type="submit" name="btn" value="save">
</form>

<?php
// if($_SERVER["REQUEST_METHOD"]=="POST"){
//     $vname=$_REQUEST['villagename'];
//     $tp=$_REQUEST['tpname'];
//     $block=$_REQUEST['blockname'];
//     $panchayat=$_REQUEST['pid'];
    
// } ?><?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\block\resources\views//block.blade.php ENDPATH**/ ?>
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class blockcontroller extends Controller
{
    public function getblock(Request $request){
        $user=DB::table('block')->get();
        return response()->json($user);
    }

    public function getpanchayat(Request $request){
        $id = $request->blockid;
        DB::select("SELECT * FROM panchayat WHERE blockid = ?", [$id]);
        $user = DB::table('panchayat')->where('blockid', $id)->get();
        return response()->json($user);
    }

    public function insert(Request $request){
        $input=$request->all();
        
        $user=DB::table('village')->insert([
            'villagename' =>$input['villagename'],
            'population' =>$input['tpname'],
            'panchayatid' =>$input['pname'],
        ]);
       
        $message='product added successfully';

        return view('/block');
    
    }
}

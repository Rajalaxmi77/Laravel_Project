<?php

namespace App\Http\Controllers;

use App\Models\student;
use App\Models\state;
use App\Models\district;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;
use App\Export\StudentExport;



class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function search(Request $request)
    {
        // Get the search query from the request
        $search = $request->input('search');

        // Filter students by name
        $students = Student::where('name', 'like', "%$search%")->paginate(5);
        // Pass data to the view
        return view('student', compact( 'students'));
    }
    
    public function index()
    {
        // Fetch states for dropdown
        //$states = DB::table('states')->get();
        $states = State::all();

        // Fetch paginated student records
        $students = Student::paginate(5);

        // Pass data to the view using compact function
        return view('student', compact('states', 'students'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function getDist(Request $request)
    {
        $stateid = $request->stateId;
        //dd($stateid);
        $res=DB::table('states')
        ->join('districts','states.stateId','=','districts.stateId')
        ->where('states.stateId',$stateid)
        ->select('districts.distId','districts.distName')
        ->get();
        return response()->json($res);

    }

    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //for storing data in database

        // Create a new instance of the Student model
        $student = new Student();
        $student->name =$request->name;
        $student->email = $request->email;
        $student->gender = $request->gender;
        $student->dob = $request->dob;
        $state = DB::table('states')->where('stateId', $request->state)->first();
        $student->state = $state->stateName;
        $dist = DB::table('districts')->where('distId', $request->dist)->first();
        $student->district = $dist->distName;

        // Save the student record
        $student->save();
        return redirect('student');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(student $student)
    {
      
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(student $student)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, student $student)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(student $student)
    {
        //
    }
    public function export(student $student)
    {
        //
        return Excel::download(new StudentExport, 'students.xlsx');
    }

}

<?php

namespace App\Export;

use App\Models\student;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;


class StudentExport implements FromCollection
{
    public function collection()
    {
        $students = student::all();
        $data = $students->map(
            function ($student) {
                return [
                    ' Id' => $student->id,
                    'Name' => $student->name,
                    'Email' => $student->email,
                    'Gender' => $student->gender,
                    'Date_of_Birth' => $student->dob,
                    'State' => $student->state,
                    'Dist' => $student->district,


                ];
            }
        );
        $header = ['Id', 'Name', 'Email','Gender','Dob','State', 'District'];
        $data->prepend($header);
        return $data;
    }
}
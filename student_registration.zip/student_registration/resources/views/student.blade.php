<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            margin-top: 50px;
        }
        .form-card {
            padding: 20px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-actions {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card form-card">
                    <h1 class="form-header">Registration Form</h1>
                    <form action="saveData" method="post">
                        @csrf
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Name:</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="email">Email:</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="dob">DOB:</label>
                                <input type="date" name="dob" id="dob" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Gender:</label><br>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="gender" id="male" value="male" class="form-check-input">
                                    <label class="form-check-label" for="male">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="gender" id="female" value="female" class="form-check-input">
                                    <label class="form-check-label" for="female">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="state">State:</label>
                                <select name="state" id="state" class="form-control">
                                    <option value="hidden">--choose--</option>
                                    @if (!empty($states))
                                        @foreach($states as $data)
                                            <option value="{{$data->stateId}}">{{$data->stateName}}</option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="dist">District:</label>
                                <select name="dist" id="dist" class="form-control">
                                    <option value="">--choose--</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions">
                            <input type="submit" class="btn btn-success" value="submit">
                            <input type="reset" class="btn btn-primary" value="reset" onclick="resetForm()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"></script>
    <script type="text/javascript">
        $(document).ready(function(){
           $("#state").change(function() {
            var op = '';
            $.ajax({
                url: 'findDist',
                type: 'get',
                dataType: 'json',
                data: {
                    stateId: $('#state').val()
                },
                success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element.distName + '</option>');
                    });
                    $('#dist').html(op);
                }
            })
            });
        });

        function resetForm() {
            // Reset all form fields
            $('form').trigger("reset");
            
            // Reset district dropdown to default option
            $('#dist').html('<option value="">--Choose--</option>');
        }
    </script>

    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card form-card">
                    <a href="{{ url('export_all_url') }}" class="btn badge-warning mt-2">Generate Excel</a> <br><br>
                    <form action="search" method="GET" class="form-inline">
                        <input type="text" name="search" placeholder="Search by name" class="form-control mr-2">
                        <button type="submit" class="btn btn-outline-secondary"><i class="fa fa-search"></i></button>
                    </form>
                    
                    <?php if(isset($students) && count($students) > 0) : ?>
                    <table class="table table-bordered mt-3">
                        <h2>Student Details</h2>
                        <thead>
                            <tr>
                                <th>Sl No</th>
                                <th>Student Name</th>
                                <th>Student Email</th>
                                <th>Date Of Birth</th>
                                <th>Gender</th>
                                <th>State</th>
                                <th>Dist</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $startingSerial = ($students->currentPage() - 1) * $students->perPage() + 1;
                            ?>
                            @foreach($students as $student)
                            <tr>
                                <td>{{ $startingSerial++ }}</td>
                                <td>{{ $student->name }}</td>
                                <td>{{ $student->email }}</td>
                                <td>{{ $student->dob }}</td>
                                <td>{{ $student->gender }}</td>
                                <td>{{ $student->state }}</td>
                                <td>{{ $student->district }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                    {{ $students->links() }} <!-- Pagination links -->
                    @else
                    <p>No records found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

<?php

use Illuminate\Support\Facades\Route;
use  App\Http\Controllers\StudentController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('/student', function () {
    return view('student');
});
Route::get('/student',[StudentController::class,'index']);
Route::get('/findDist',[StudentController::class,'getDist']);
Route::post('/saveData',[StudentController::class,'store']);
Route::get('/export_all_url',[StudentController::class,'export']);
Route::get('search', [StudentController::class,'search']);



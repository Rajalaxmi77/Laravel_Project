<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .form-container {
            margin-top: 50px;
        }
        .form-card {
            padding: 20px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-header {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-actions {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card form-card">
                    <h1 class="form-header">Registration Form</h1>
                    <form action="saveData" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="name">Name:</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="email">Email:</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="dob">DOB:</label>
                                <input type="date" name="dob" id="dob" class="form-control">
                            </div>
                            <div class="form-group col-md-6">
                                <label>Gender:</label><br>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="gender" id="male" value="male" class="form-check-input">
                                    <label class="form-check-label" for="male">Male</label>
                                </div>
                                <div class="form-check form-check-inline">
                                    <input type="radio" name="gender" id="female" value="female" class="form-check-input">
                                    <label class="form-check-label" for="female">Female</label>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="state">State:</label>
                                <select name="state" id="state" class="form-control">
                                    <option value="hidden">--choose--</option>
                                    <?php if(!empty($states)): ?>
                                        <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($data->stateId); ?>"><?php echo e($data->stateName); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </select>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="dist">District:</label>
                                <select name="dist" id="dist" class="form-control">
                                    <option value="">--choose--</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-actions">
                            <input type="submit" class="btn btn-success" value="submit">
                            <input type="reset" class="btn btn-primary" value="reset" onclick="resetForm()">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
           $("#state").change(function() {
            var op = '';
            $.ajax({
                url: 'findDist',
                type: 'get',
                dataType: 'json',
                data: {
                    stateId: $('#state').val()
                },
                success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element.distName + '</option>');
                    });
                    $('#dist').html(op);
                }
            })
            });
        });

        function resetForm() {
            // Reset all form fields
            $('form').trigger("reset");
            
            // Reset district dropdown to default option
            $('#dist').html('<option value="">--Choose--</option>');
        }
    </script>

    <div class="container form-container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card form-card">
                    <a href="<?php echo e(url('export_all_url')); ?>" class="btn badge-warning mt-2">Generate Excel</a> <br><br>
                    <form action="search" method="GET" class="form-inline">
                        <input type="text" name="search" placeholder="Search by name" class="form-control mr-2">
                        <button type="submit" class="btn btn-outline-secondary"><i class="fa fa-search"></i></button>
                    </form>
                    
                    <?php if(isset($students) && count($students) > 0) : ?>
                    <table class="table table-bordered mt-3">
                        <h2>Student Details</h2>
                        <thead>
                            <tr>
                                <th>Sl No</th>
                                <th>Student Name</th>
                                <th>Student Email</th>
                                <th>Date Of Birth</th>
                                <th>Gender</th>
                                <th>State</th>
                                <th>Dist</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $startingSerial = ($students->currentPage() - 1) * $students->perPage() + 1;
                            ?>
                            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($startingSerial++); ?></td>
                                <td><?php echo e($student->name); ?></td>
                                <td><?php echo e($student->email); ?></td>
                                <td><?php echo e($student->dob); ?></td>
                                <td><?php echo e($student->gender); ?></td>
                                <td><?php echo e($student->state); ?></td>
                                <td><?php echo e($student->district); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($students->links()); ?> <!-- Pagination links -->
                    <?php else: ?>
                    <p>No records found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravelnew\student_registration\resources\views/student.blade.php ENDPATH**/ ?>
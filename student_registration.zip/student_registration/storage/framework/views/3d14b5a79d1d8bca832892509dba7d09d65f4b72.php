<h1></h1>
<form action="saveData" method="post">
    <?php echo csrf_field(); ?>
    Name:
    <input type="text" name="name" id="name"><br><br>
    Email:
    <input type="text" name="email" id="email"><br><br>
    DOB:
    <input type="date" name="dob" id="dob"><br><br>
    Gender:
    <input type="radio" name="gender" id="male" value="male">Male
    <input type="radio" name="gender" id="female" value="female">Female <br><br>
    State:
    <select name="state" id="state">
        <option value="hidden">--choose--</option>
          <?php if(!empty($r)): ?>
    <?php $__currentLoopData = $r; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($data->stateId); ?>"><?php echo e($data->stateName); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
    </select>
    <br><br>
    District:
    <select name="dist" id="dist">
        <option value="">--choose--</option>
    </select>
    <br><br>
    <input type="submit" value="submit">
    <input type="reset" value="reset" onclick="resetForm()">
</form>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
           $("#state").change(function() {
            op='';
            $.ajax({
                url:'findDist',
                type:'get',
                dataType:'json',
                data:{
                    stateId:$('#state').val()
                },
            success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element
                            .distName + '</option>');
                    });
                    $('#dist').html(op);

                }
            })

            })
        });

        function resetForm() {
        // Reset all form fields
        $('form').trigger("reset");
        
        // Reset district dropdown to default option
        $('#dist').html('<option value="">--Choose--</option>');
    }
    </script>
    <?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravelnew\student_registration\resources\views//student.blade.php ENDPATH**/ ?>
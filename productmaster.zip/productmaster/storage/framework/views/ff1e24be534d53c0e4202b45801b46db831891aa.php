
<?php if(isset($u)): ?>
<?php $__currentLoopData = $u; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<form action="updates" method="post">
    Name:<input type="text" name="prodname" value="<?php echo e(isset($uu->prodname)?$uu->prodname:''); ?>"/>
    <br>
    Role:<input type="text" name="prodrate" value="<?php echo e(isset($uu->prodrate)?$uu->prodrate:''); ?>"/>
    <br>
    Password:<input type="text" name="prodqty" value="<?php echo e(isset($uu->prodqty)?$uu->prodqty:''); ?>"/>
    <br>
    <input type="submit" name="btn" value="update">
    <input type="hidden" name="email" value="<?php echo e(isset($uu->email)?$uu->email:''); ?>"/>
    <?php echo csrf_field(); ?>
</form>


<table class="table table-bordered">
    <tr>
        <th>prodid</th>
        <th>prodname</th>
        <th>prodrate</th>
        <th>prodqty</th>
        <th>Action</th>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($user->prodid); ?></td>
        <td><?php echo e($user->prodname); ?></td>
        <td><?php echo e($user->prodrate); ?></td>
        <td><?php echo e($user->prodqty); ?></td>
        <td><a href='editusers?email=<?php echo e($user->email); ?>'>Edit</a> | <a href='deleteusers?email=<?php echo e($user->email); ?>'>Delete</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table><?php /**PATH C:\Users\rajalaxmi.s\Desktop\productmaster\resources\views/order.blade.php ENDPATH**/ ?>
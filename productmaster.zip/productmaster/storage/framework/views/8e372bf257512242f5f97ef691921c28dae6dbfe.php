<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management System</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('css/style.css')); ?>">
<script type="text/javascript" src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
</head>
<body>
    <div class="container">
        <!-- Display Orders and Order Form here -->
        <form action="<?php echo e(url('/order')); ?>" method="post" onsubmit="return chk()">
            <?php echo csrf_field(); ?>
            Product Name: <input type="text" name="prodname" id="prodname">
            <br>
            Product Rate: <input type="text" readonly name="prodrate" id="prodrate">
            <br>
            Quantity: <input type="text" name="prodqty" id="prodqty"><span id="qty"></span>
            <br>
            <input type="hidden" name="prodid" id="prodid">
            <input type="submit" name="btn" value="order">
        </form>

        <!-- Display Orders Table -->
        <div class="product-display">
            <h1 align="center">List of Orders</h1>
            <center>
                <table class="product-display-table" border="">
                    <thead>
                        <tr>
                            <th>Order Id</th>
                            <th>Product Name</th>
                            <th>Order Date</th>
                            <th>Order Qty</th>
                            <th>Product Rate</th>
                            <th>Order Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->orderid); ?></td>
                                <td><?php echo e($order->prodname); ?></td>
                                <td><?php echo e($order->orderdate); ?></td>
                                <td><?php echo e($order->orderqty); ?></td>
                                <td><?php echo e($order->prodrate); ?></td>
                                <td><?php echo e($order->ordervalue); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </center>
        </div>
    </div>

    <!-- Include your scripts here -->
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            $("#prodname").blur(function(){
                $.ajax({
                    url: "<?php echo e(url('/get-product')); ?>",
                    type: "POST",
                    dataType: "JSON",
                    data: {prodname: $("#prodname").val()},
                    success: function(res){
                        $("#prodrate").val(res.prodrate);
                        $("#oldprodqty").val(res.prodqty);
                        $("#prodid").val(res.prodid);
                    }
                })
            })
        })

        function chk(){
            prodqty = parseInt(document.getElementById('prodqty').value);
            oldprodqty = parseInt(document.getElementById('oldprodqty').value);
            
            if(oldprodqty >= prodqty) {
                return true;
            } else {
                document.getElementById('qty').innerHTML = "plz select less qty";
                return false;
            }
        }
    </script>
</body>
</html>




<?php /**PATH C:\Users\rajalaxmi.s\Desktop\productmaster\resources\views/index.blade.php ENDPATH**/ ?>
<!-- viewproduct.blade.php -->
<!DOCTYPE html>
<html>
<head>
    <title>View Product</title>
</head>
<body>
    <h1>View Product</h1>

        <table border="1">
            <tr>
                <th>Product ID</th>
                <th>Product Rate</th>
                <th>Order Quantity</th>
                <th>Order Value</th>
            </tr>
            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($order->prodid); ?></td>
                    <td><?php echo e($order->prodrate); ?></td>
                    <td><?php echo e($order->orderqty); ?></td>
                    <td><?php echo e($order->ordervalue); ?></td>
                    <td><a href='editproduct?orderid=<?php echo e($order->orderid); ?>'>Edit</a> | <a href='deleteOrder?orderid=<?php echo e($order->orderid); ?>'>Delete</a></td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
</body>
</html>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\productmaster\resources\views//viewproduct.blade.php ENDPATH**/ ?>
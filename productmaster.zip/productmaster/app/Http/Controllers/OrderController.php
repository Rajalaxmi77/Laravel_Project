<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
// use Illuminate\Support\Facades\View;
use DB;

class OrderController extends Controller{
    public function getproduct(Request $request){
        $input=$request->all();
        $prod=DB::table('product_master')->where('prodname',$input['prodname'])->first();
        return response()->json($prod);
    }
    function product(Request $request){
    $input = $request->all();
    DB::table('order_master')->insert([
        'prodid' => $input['prodid'],
        'prodrate' => $input['prodrate'],
        'orderqty' => $input['newprodqty'], 
        'ordervalue' => $input['prodrate'] * $input['newprodqty'],
    ]);
    $orders = DB::table('order_master')->get();
    return view('viewproduct', ['orders' => $orders]);
    }
    function editOrder(Request $request)
    {
        $id=$request->orderid;
        $order = DB::table('order_master')->find($id);
        return view('editOrder', ['orders' => $order]);
    }

    function deleteOrder(Request $request)
    {
        $id=$request->orderid;
        $orders=DB::table('order_master')->where('orderid', $id)->delete();
        return view('viewproduct',['orders' => $orders]);
    }
    
}


<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\OrderController;
use Illuminate\Support\Facades\DB;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/product',function(){
    return view('product');
});
Route::post('/getproduct',[OrderController::class,'getproduct']);
Route::post('/product',[OrderController::class,'product']);


Route::get('/viewproduct', function () {
    $orders = DB::table('order_master')->get();
    return View::make('viewproduct')->with('orders', $orders);
});

Route::get('/editOrder', [OrderController::class,'editOrder']);
Route::get('/deleteOrder', [OrderController::class, 'deleteOrder']);

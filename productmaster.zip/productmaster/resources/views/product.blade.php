<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"></script>
<script type="text/javascript">
    $(document).ready(function()
    {
        $("#prodname").blur(function()
        {
            $.ajax({
                url:"/getproduct/",
                type:"POST",
                dataType:"JSON",
                data:{prodname:$("#prodname").val(),_token:$("input[name=_token]").val()},
                success:function(result){
                    if(result){
                        $("#prodrate").val(result.prodrate);
                        $("#prodqty").val(result.prodqty);
                        $("#prodid").val(result.prodid);
                        $("#prodmsg").html("");
                    }else{
                        $("#prodrate").val("");
                        $("#prodmsg").html("prod not found");
                    }
                }
            })
        })
    })
    
</script>
<script type="text/javascript">
    function show()
    {
        errorQty=true;
        newQty=parseInt(document.getElementById('newprodqty').value);
        qty=parseInt(document.getElementById('prodqty').value);
        qtyValid();

        function qtyValid()
        {
            if(newQty >= qty){
                errorQty=false;
                document.getElementById('qtymsg').innerHTML="plz select less qty";
            }else{
                errorQty=true;
                document.getElementById('qtymsg').innerHTML="";
            }
        }
        if(errorQty){
            return true;
        }else{
            return false;
        }
    }
</script>
<form method="post" onsubmit="return show()" >
Product Name:
<input type="text" name="prodname" id="prodname"><span id="prodmsg"></span>
<br>
Rate:
<input type="text" name="prodrate" id="prodrate">
<br>
Qty:
<input type="text" name="newprodqty" id="newprodqty"><span id="qtymsg"></span>
<br>
<input type="hidden" name="prodqty" id="prodqty">
<br>
<input type="hidden" name="prodid" id="prodid">
<br>
<input type="submit" name="btn" id="btn">
@csrf
</form>    
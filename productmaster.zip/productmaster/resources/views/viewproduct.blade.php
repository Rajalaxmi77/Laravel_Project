<table border="1">
            <tr>
                <th>Order ID</th>
                <th>Order Date</th>
                <th>Product ID</th>
                <th>Product Rate</th>
                <th>Order Quantity</th>
                <th>Order Value</th>
                <th>Action</th>
            </tr>
            @foreach($orders as $order)
                <tr>
                    <td>{{ $order->orderid }}</td>
                    <td>{{ $order->orderdate }}</td>
                    <td>{{ $order->prodid }}</td>
                    <td>{{ $order->prodrate }}</td>
                    <td>{{ $order->orderqty }}</td>
                    <td>{{ $order->ordervalue }}</td>
                    <td>
                        <a href='editproduct?orderid={{$order->orderid}}'>Edit</a> | 
                        <a href='deleteOrder?orderid={{$order->orderid}}'>Delete</a>
                    </td>

                </tr>
            @endforeach
</table>


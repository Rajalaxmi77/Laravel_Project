<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <script src="{{URL::asset('js/bootstrap.min.js')}}"></script>
     <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h1 style="color: blue; font-family: 'Times New Roman', Times, serif; font-size: 28px; font-weight: bold; text-decoration: underline;">Student Registration</h1>

    <form action="savedata" method="post">
        @csrf
        <label for="name">Name:</label>
        <input type="text" id="name" value="{{ old('name') }}" name="name">
        @if ($errors->has('name'))
        <span class="text-danger">{{ $errors->first('name') }}</span>
        @endif<br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" value="{{ old('email') }}" name="email">
        @if ($errors->has('email'))
        <span class="text-danger">{{ $errors->first('email') }}</span>
        @endif<br> <br>

        <label for="phone">Phone:</label>
        <input type="tel" id="phone" value="{{ old('phone') }}" name="phone">
        @if ($errors->has('phone'))
        <span class="text-danger">{{ $errors->first('phone') }}</span>
        @endif<br><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="Male" {{ old('gender') == 'Male' ? 'checked' : '' }}>
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="Female" {{ old('gender') == 'Female' ? 'checked' : '' }}>
        <label for="female">Female</label>
        <input type="radio" id="other" name="gender" value="Other" {{ old('gender') == 'Other' ? 'checked' : '' }}>
        <label for="other">Other</label>
        @if ($errors->has('gender'))
        <span class="text-danger">{{ $errors->first('gender') }}</span>
        @endif<br> <br>

        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" value="{{ old('dob') }}" name="dob">
        @if ($errors->has('dob'))
        <span class="text-danger">{{ $errors->first('dob') }}</span>
        @endif
        <br> <br>

        <label for="address">Address:</label>
        <input type="text" id="address" value="{{ old('address') }}" name="address">
        @if ($errors->has('address'))
        <span class="text-danger">{{ $errors->first('address') }}</span>
        @endif<br> <br>

        <label for="state">State:</label>
        <select id="state" name="state">
            <option value="">--Select--</option>

        </select>
        @if ($errors->has('state'))
        <span class="text-danger">{{ $errors->first('state') }}</span>
        @endif<br> <br>

        <label for="district">District:</label>
        <select id="district" name="district">
            <option value="">--Choose--</option>
        </select>
        @if ($errors->has('district'))
        <span class="text-danger">{{ $errors->first('district') }}</span>
        @endif<br><br>

        <button type="submit" style="background-color: Green; color: #fff; padding: 3px 10px; border: solid; cursor: pointer;">Submit</button>
        <button type="reset" style="background-color: Blue; color: #fff; padding: 3px 10px; border: solid; cursor: pointer; margin-left: 10px;" onclick="resetForm()">Reset</button>
    </form>
</body>
<?php if (isset($data)) : ?>
    <table class="table table-bordered">
        <h2>Student Details</h2>
        <thead>
            <tr>
                <th>Sl No</th>
                <th>Student Name</th>
                <th>Student Email</th>
                <th>Mobile Number</th>
                <th>Date Of Birth</th>
                <th>Gender</th>
                <th>Address</th>
                <th>State</th>
                <th>Dist</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            ?>
            @foreach($data as $view)
            <tr>
                <td>{{ $serial++ }}</td>
                <td>{{ $view->studentName}}</td>
                <td>{{ $view->studentEmail}}</td>
                <td>{{ $view->studentPhone}}</td>
                <td>{{ $view->studentDob}}</td>
                <td>{{ $view->studentGender}}</td>
                <td>{{ $view->studentAddress}}</td>
                <td>{{ $view->studentState}}</td>
                <td>{{ $view->studentDist}}</td>
            </tr>
            @endforeach
        </tbody>
    </table>
<?php endif; ?>
<a href="{{ url('export_all_url') }}" class="btn badge-warning mt-2 ">Generate Excel</a> <br> <br>

</html>
<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
<script type="text/javascript">
    $(document).ready(function() {
        $.ajax({
            url: "findstate",
            type: "get",
            dataType: "JSON",
            data: {},
            success: function(res) {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                obj.forEach(element => {
                    $('#state').append('<option value="' + element.stateId + '">' + element
                        .stateName + '</option>');

                });

            }
        })
        $("#state").change(function() {
            op = '';
            $.ajax({
                url: "findDist",
                type: "get",
                dataType: "JSON",
                data: {
                    stateid: $('#state').val()
                },
                success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element
                            .distName + '</option>');
                    });
                    $('#district').html(op);


                }
            })
        })
    })

    function resetForm() {
        // Reset all form fields
        $('form').trigger("reset");
        
        // Reset district dropdown to default option
        $('#district').html('<option value="">--Choose--</option>');
    }

</script>

</body>

</html>


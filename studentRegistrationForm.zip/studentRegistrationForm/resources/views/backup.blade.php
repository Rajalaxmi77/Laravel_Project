<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1 class="text-center" style="color: blue; font-family: 'Times New Roman', Times, serif; font-size: 28px; font-weight: bold; text-decoration: underline;">Student Registration</h1>

        <form action="savedata" method="post">
            @csrf
            <div class="form-group">
                <label for="name">Name:</label>
                <input type="text" id="name" class="form-control" value="{{ old('name') }}" name="name">
                @if ($errors->has('name'))
                <span class="text-danger">{{ $errors->first('name') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" class="form-control" value="{{ old('email') }}" name="email">
                @if ($errors->has('email'))
                <span class="text-danger">{{ $errors->first('email') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="phone">Phone:</label>
                <input type="tel" id="phone" class="form-control" value="{{ old('phone') }}" name="phone">
                @if ($errors->has('phone'))
                <span class="text-danger">{{ $errors->first('phone') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label>Gender:</label><br>
                <div class="form-check form-check-inline">
                    <input type="radio" id="male" name="gender" value="Male" class="form-check-input" {{ old('gender') == 'Male' ? 'checked' : '' }}>
                    <label for="male" class="form-check-label">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" id="female" name="gender" value="Female" class="form-check-input" {{ old('gender') == 'Female' ? 'checked' : '' }}>
                    <label for="female" class="form-check-label">Female</label>
                </div>
                <div class="form-check form-check-inline">
                    <input type="radio" id="other" name="gender" value="Other" class="form-check-input" {{ old('gender') == 'Other' ? 'checked' : '' }}>
                    <label for="other" class="form-check-label">Other</label>
                </div>
                @if ($errors->has('gender'))
                <span class="text-danger">{{ $errors->first('gender') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input type="date" id="dob" class="form-control" value="{{ old('dob') }}" name="dob">
                @if ($errors->has('dob'))
                <span class="text-danger">{{ $errors->first('dob') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="address">Address:</label>
                <input type="text" id="address" class="form-control" value="{{ old('address') }}" name="address">
                @if ($errors->has('address'))
                <span class="text-danger">{{ $errors->first('address') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="state">State:</label>
                <select id="state" class="form-control" name="state">
                    <option value="">--Select--</option>
                </select>
                @if ($errors->has('state'))
                <span class="text-danger">{{ $errors->first('state') }}</span>
                @endif
            </div>

            <div class="form-group">
                <label for="district">District:</label>
                <select id="district" class="form-control" name="district">
                    <option value="">--Choose--</option>
                </select>
                @if ($errors->has('district'))
                <span class="text-danger">{{ $errors->first('district') }}</span>
                @endif
            </div>

            <button type="submit" class="btn btn-success">Submit</button>
            <button type="reset" class="btn btn-primary" onclick="resetForm()">Reset</button>
        </form>

        @if (isset($data))
        <div class="table-responsive mt-4">
            <h2>Student Details</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Sl No</th>
                        <th>Student Name</th>
                        <th>Student Email</th>
                        <th>Mobile Number</th>
                        <th>Date Of Birth</th>
                        <th>Gender</th>
                        <th>Address</th>
                        <th>State</th>
                        <th>Dist</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $serial = 1;
                    ?>
                    @foreach($data as $view)
                    <tr>
                        <td>{{ $serial++ }}</td>
                        <td>{{ $view->studentName}}</td>
                        <td>{{ $view->studentEmail}}</td>
                        <td>{{ $view->studentPhone}}</td>
                        <td>{{ $view->studentDob}}</td>
                        <td>{{ $view->studentGender}}</td>
                        <td>{{ $view->studentAddress}}</td>
                        <td>{{ $view->studentState}}</td>
                        <td>{{ $view->studentDist}}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        <a href="{{ url('export_all_url') }}" class="btn btn-warning mt-2">Export to Excel</a>
        @endif
    </div>
</body>

<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
<script type="text/javascript">
    $(document).ready(function() {
        $.ajax({
            url: "findstate",
            type: "get",
            dataType: "JSON",
            data: {},
            success: function(res) {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                obj.forEach(element => {
                    $('#state').append('<option value="' + element.stateId + '">' + element
                        .stateName + '</option>');

                });

            }
        })
        $("#state").change(function() {
            op = '';
            $.ajax({
                url: "findDist",
                type: "get",
                dataType: "JSON",
                data: {
                    stateid: $('#state').val()
                },
                success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element
                            .distName + '</option>');
                    });
                    $('#district').html(op);


                }
            })
        })
    })
    function resetForm() {
        // Reset all form fields
        $('form').trigger("reset");
        
        // Reset district dropdown to default option
        $('#district').html('<option value="">--Choose--</option>');
    }

</script>

</html>

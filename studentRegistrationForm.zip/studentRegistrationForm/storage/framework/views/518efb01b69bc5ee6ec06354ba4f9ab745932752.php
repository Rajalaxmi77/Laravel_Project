<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
     <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <h1 style="color: blue; font-family: 'Times New Roman', Times, serif; font-size: 28px; font-weight: bold; text-decoration: underline;">Student Registration</h1>

    <form action="savedata" method="post">
        <?php echo csrf_field(); ?>
        <label for="name">Name:</label>
        <input type="text" id="name" value="<?php echo e(old('name')); ?>" name="name">
        <?php if($errors->has('name')): ?>
        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
        <?php endif; ?><br><br>

        <label for="email">Email:</label>
        <input type="email" id="email" value="<?php echo e(old('email')); ?>" name="email">
        <?php if($errors->has('email')): ?>
        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
        <?php endif; ?><br> <br>

        <label for="phone">Phone:</label>
        <input type="tel" id="phone" value="<?php echo e(old('phone')); ?>" name="phone">
        <?php if($errors->has('phone')): ?>
        <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
        <?php endif; ?><br><br>

        <label>Gender:</label>
        <input type="radio" id="male" name="gender" value="Male" <?php echo e(old('gender') == 'Male' ? 'checked' : ''); ?>>
        <label for="male">Male</label>
        <input type="radio" id="female" name="gender" value="Female" <?php echo e(old('gender') == 'Female' ? 'checked' : ''); ?>>
        <label for="female">Female</label>
        <input type="radio" id="other" name="gender" value="Other" <?php echo e(old('gender') == 'Other' ? 'checked' : ''); ?>>
        <label for="other">Other</label>
        <?php if($errors->has('gender')): ?>
        <span class="text-danger"><?php echo e($errors->first('gender')); ?></span>
        <?php endif; ?><br> <br>

        <label for="dob">Date of Birth:</label>
        <input type="date" id="dob" value="<?php echo e(old('dob')); ?>" name="dob">
        <?php if($errors->has('dob')): ?>
        <span class="text-danger"><?php echo e($errors->first('dob')); ?></span>
        <?php endif; ?>
        <br> <br>

        <label for="address">Address:</label>
        <input type="text" id="address" value="<?php echo e(old('address')); ?>" name="address">
        <?php if($errors->has('address')): ?>
        <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
        <?php endif; ?><br> <br>

        <label for="state">State:</label>
        <select id="state" name="state">
            <option value="">--Select--</option>

        </select>
        <?php if($errors->has('state')): ?>
        <span class="text-danger"><?php echo e($errors->first('state')); ?></span>
        <?php endif; ?><br> <br>

        <label for="district">District:</label>
        <select id="district" name="district">
            <option value="">--Choose--</option>
        </select>
        <?php if($errors->has('district')): ?>
        <span class="text-danger"><?php echo e($errors->first('district')); ?></span>
        <?php endif; ?><br><br>

        <button type="submit" style="background-color: Green; color: #fff; padding: 3px 10px; border: solid; cursor: pointer;">Submit</button>
        <button type="reset" style="background-color: Blue; color: #fff; padding: 3px 10px; border: solid; cursor: pointer; margin-left: 10px;" onclick="resetForm()">Reset</button>
    </form>
</body>
<?php if (isset($data)) : ?>
    <table class="table table-bordered">
        <h2>Student Details</h2>
        <thead>
            <tr>
                <th>Sl No</th>
                <th>Student Name</th>
                <th>Student Email</th>
                <th>Mobile Number</th>
                <th>Date Of Birth</th>
                <th>Gender</th>
                <th>Address</th>
                <th>State</th>
                <th>Dist</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $serial = 1;
            ?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $view): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($serial++); ?></td>
                <td><?php echo e($view->studentName); ?></td>
                <td><?php echo e($view->studentEmail); ?></td>
                <td><?php echo e($view->studentPhone); ?></td>
                <td><?php echo e($view->studentDob); ?></td>
                <td><?php echo e($view->studentGender); ?></td>
                <td><?php echo e($view->studentAddress); ?></td>
                <td><?php echo e($view->studentState); ?></td>
                <td><?php echo e($view->studentDist); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<a href="<?php echo e(url('export_all_url')); ?>" class="btn badge-warning mt-2 ">Generate Excel</a> <br> <br>

</html>
<script type="text/javascript" src="<?php echo e(URL::asset('js/jquery.js')); ?>"> </script>
<script type="text/javascript">
    $(document).ready(function() {
        $.ajax({
            url: "findstate",
            type: "get",
            dataType: "JSON",
            data: {},
            success: function(res) {
                json_text = JSON.stringify(res);
                obj = JSON.parse(json_text);
                obj.forEach(element => {
                    $('#state').append('<option value="' + element.stateId + '">' + element
                        .stateName + '</option>');

                });

            }
        })
        $("#state").change(function() {
            op = '';
            $.ajax({
                url: "findDist",
                type: "get",
                dataType: "JSON",
                data: {
                    stateid: $('#state').val()
                },
                success: function(res) {
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    obj.forEach(element => {
                        op += ('<option value="' + element.distId + '">' + element
                            .distName + '</option>');
                    });
                    $('#district').html(op);


                }
            })
        })
    })

    function resetForm() {
        // Reset all form fields
        $('form').trigger("reset");
        
        // Reset district dropdown to default option
        $('#district').html('<option value="">--Choose--</option>');
    }

</script>

</body>

</html>

<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\studentRegistrationForm\resources\views//student.blade.php ENDPATH**/ ?>
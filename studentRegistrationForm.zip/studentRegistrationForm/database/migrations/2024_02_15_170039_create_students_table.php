<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateStudentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('students', function (Blueprint $table) {
             $table->increments('studentId');
            $table->string('studentName',200);
            $table->string('studentEmail',200);
            $table->date('studentDob')->nullable();
            $table->string('studentPhone',20);
            $table->string('studentGender',20);
            $table->string('studentAddress',20);
            $table->string('studentState',20);
            $table->string('studentDist',20);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('students');
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\student;
use App\Models\district;
use App\Models\state;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\StudentsExport;

class StudentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $res = DB::table('states')->get();
        return response()->json($res);
    }
    public function findDist(Request $request)
    {
        $stateid = $request->input('stateid');
        $res = DB::table('states')
            ->join('districts', 'states.stateId', '=', 'districts.stateId')
            ->where('states.stateId', $stateid)
            ->select('districts.distId', 'districts.distName')
            ->get();
        return response()->json($res);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $rules = [
            'name' => ['required', 'string', 'max:50', 'regex:/^[^\d]+$/'],
            'email' => ['required', 'email', 'max:80'],
            'phone' => ['required', 'numeric', 'digits_between:9,10'],
            'dob' => 'required|date|date_format:Y-m-d|before_or_equal:today',
            'gender' => 'required|in:Male,Female,Other',
            'address' => 'required|string|max:255',
            'state' => 'required|exists:states,stateId',
            'district' => 'required|exists:districts,distId',
        ];

        $messages = [
            'name.required' => 'Please fill up the name field.',
            'name.string' => 'The Name field can not contain numbers.',
            'name.max' => 'Name should be less than 50 characters.',
            'name.regex' => 'The Name field must not contain numbers.',
            'email.required' => 'The Email field is required.',
            'email.email' => 'The Email must be a valid email address.',
            'email.max' => 'The Email field may not be greater than 80 characters.',
            'phone.required' => 'The Phone field is required.',
            'phone.numeric' => 'The Phone field must be a number.',
            'phone.digits_between' => 'The Phone number must be between 9 and 10 digits.',
            'dob.required' => 'The Date of Birth field is required.',
            'dob.date' => 'The Date of Birth field must be a valid date.',
            'dob.date_format' => 'The Date of Birth must be in the format YYYY-MM-DD.',
            'dob.before_or_equal' => 'The Date of Birth must not be a future date.',
            'gender.required' => 'The Gender field is required.',
            'gender.in' => 'Please select a valid gender.',
            'address.required' => 'The Address field is required.',
            'address.string' => 'The Address field must be a string.',
            'address.max' => 'The Address field may not be greater than 255 characters.',
            'state.required' => 'The State field is required.',
            'state.exists' => 'Please select a valid state.',
            'district.required' => 'The District field is required.',
            'district.exists' => 'Please select a valid district.',
        ];
        $validator = Validator::make($request->all(), $rules, $messages);
        if ($validator->fails()) {
            return redirect('student')
                ->withErrors($validator)
                ->withInput();
        }
        $cont = new Student();
        $cont->studentName = $request->name;
        $cont->studentEmail = $request->email;
        $cont->studentPhone = $request->phone;
        $cont->studentGender = $request->gender;
        $cont->studentDob = $request->dob;
        $cont->studentAddress = $request->address;
        $state = DB::table('states')->where('stateId', $request->state)->first();
        $cont->studentState = $state->stateName;
        $district = DB::table('districts')->where('distId', $request->district)->first();
        $cont->studentDist = $district->distName;
        $cont->save();
        return redirect('student');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function show(Student $student)
    {
        $sql = Student::all();  //Student model name 
        return view('/student', ['data' => $sql]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function edit(Student $student)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Student $student)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Student  $student
     * @return \Illuminate\Http\Response
     */
    public function destroy(Student $student)
    {
        //
    }
    public function Export_Excel()
    {
        return Excel::download(new StudentsExport, 'students.xlsx');
    }
}
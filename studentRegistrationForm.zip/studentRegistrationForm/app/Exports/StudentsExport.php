<?php

namespace App\Exports;

use App\Models\student;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\Concerns\FromCollection;


class StudentsExport implements FromCollection
{
    public function collection()
    {
        $students = student::all();
        $data = $students->map(
            function ($student) {
                return [
                    ' Id' => $student->studentId,
                    'Name' => $student->studentName,
                    'Email' => $student->studentEmail,
                    'Phone' => $student->studentPhone,
                    'Gender' => $student->studentGender,
                    'Date_of_Birth' => $student->studentDob,
                    'Address' => $student->studentAddress,
                    'State' => $student->studentState,
                    'Dist' => $student->studentDist,


                ];
            }
        );
        $header = ['StudentId', 'Name', 'Email', 'Phone No', 'Gender','Dob', 'Address', 'State', 'District'];
        $data->prepend($header);
        return $data;
    }
}
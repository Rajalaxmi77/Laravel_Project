<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use PDF;

class pdfController extends Controller
{
    public function generatePDF()
    {
        $data=[
            'title'=>'welcome to laravel',
            'date'=>date('m/d/Y')
        ];
        $pdf=PDF::loadView('myPDF',$data);
        return $pdf->download('test.pdf');
    }
}

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\orderController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/orderpage', function () {
    return view('order');
});
Route::get('/orderpage',[orderController::class,'getproduct']);
Route::get('/getprice',[orderController::class,'getproductprice']);
Route::post('/orderpage',[orderController::class,'saveproduct']);
Route::get('/deleteOrder',[orderController::class,'deleteOrder']);
Route::get('/getOrderDetails', [orderController::class,'getOrderDetails']);

Route::get('/editOrder', [orderController::class, 'editOrder']);
Route::get('/updateOrder', [orderController::class, 'updateOrder']);

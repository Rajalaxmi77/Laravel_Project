<?php
// public function editOrder(Request $request)
//     {
//         $id = $request->order_id;
//         DB::select("select * from order_master where order_id='$id'");
//         $order=DB::table('order_master')->first();
//         return view('editOrder', ['results' => $order]);
//     }


    
//     public function updateOrder(Request $request)
//     {
//         $input = $request->all();
//         $id=$request->order_id;
        
//         // Update the order data
//         DB::table('order_master')
//             ->where('order_id', $id)
//             ->update([
//                 'order_qty' => $input['orderqty'],
//                 'order_date' => $input['orderdate'],
//                 // Update other fields as needed
//             ]);

//         // Redirect back to the order page or any other page you prefer
//         return redirect('orderpage')->with('message', 'Order updated successfully');
//     }
?>
<!-- <link rel="stylesheet" href="{{URL::asset('css/styles.css)}}">
<script src="{{URL::asset('js/jquery.js')}}"></script> -->

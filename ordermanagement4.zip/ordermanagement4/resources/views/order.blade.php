
<form id="orderForm" action="" method="post" onsubmit="return chkItem()">
    @csrf
    <label>Choose Product:</label>
    <select name="prodname" id="prodname">
        <option hidden="hidden">--select product--</option>
       @if (!empty($sql))
    @foreach($sql as $data)
        <option value="{{$data->product_id}}">{{$data->name}}</option>
    @endforeach
@endif
    </select>
    <label for="">Order Date:</label>
     <input type="date"  name="orderdate" id="orderdate" >
    <label for=""> Order Quantity: </label>
    <input type="hidden" name="order_id" id="order_id">
     <input type="text" name="orderqty" id="orderqty"><span id="qtymsg"></span>
     <input type="hidden" name="product_qty" id="product_qty">
     <br>
     <br>
    <label for="">Unit Price: </label>
     <input type="text" name="unit_price" id="unit_price" readonly>
     <br>
     <br>
    <input type="submit" name="btn_save" id="btn_save" value="Save">
    <!-- <input type="submit" name="btn_update" id="btn_update" value="Update"> -->

    <!-- <a href='updateOrder' name="btn_update" id="btn_update">Update</a> -->
    <button type="submit" id="btn_update" name="btn_update"><a href='updateOrder'>Update</a></button>

</form>

<script type="text/javascript" src="{{URL::asset('js/jquery.js')}}"> </script>
<script type="text/javascript">
    $(document).ready(function(){
        $("#prodname").blur(function(){
            $.ajax({
                url:"getprice",
                type:"get",
                dataType:"JSON",
                data:{prodname:$("#prodname").val()},
                success:function(res){
                    json_text=JSON.stringify(res);
                    obj=JSON.parse(json_text);
                    $("#unit_price").val(obj.unit_price);
                    $("#product_qty").val(obj.product_qty);
                    
                }
            })
        })
    })

    function chkItem(){
        errQty=true;
        newqty=parseInt(document.getElementById('orderqty').value);
        qty=parseInt(document.getElementById('product_qty').value);
        qtyValid();

        function qtyValid(){
            if(newqty >=qty){
                errorQty=false;
                document.getElementById('qtymsg').innerHTML="plz select less qty";
            }else{
                errorQty=true;
            }
        }
        if(errorQty){
            return true;
        }else{
            return false;
        }
    }
    
    </script>
<?php
$sl_no=1;

?>

<table border="1">
    <thead>
        <tr>
           <th>Sl NO</th>
            <th>product name</th>
            <th>order date</th>
            <th>order qty</th>
            <th>unit price</th>
            <th>order value</th>
            <th>Action</th>
        </tr>
    </thead>
    @if (!empty($results))
    @foreach($results as $r)
    <tr>
        <td>
           {{ $sl_no++ }}
        </td>
        <td>{{$r->name}}</td>
        <td>{{$r->order_date}}</td>
        <td>{{$r->order_qty}}</td>
        <td>{{$r->unit_price}}</td>
        <td>{{ $r->order_qty * $r->unit_price }}</td>
        <td>
            <a href='editOrder' class='editOrder' data-orderid='{{ $r->order_id }}'>Edit</a> | 
            <a href='deleteOrder?order_id={{$r->order_id}}'>Delete</a>
        </td>
        
    </tr>
    @endforeach
    @endif
</table>

<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('click', '.editOrder', function(e){
            e.preventDefault();
            var formData = $("#orderForm").serialize(); // Serialize form data
            var orderId = $(this).data('orderid');
            
            
            $.ajax({
                url: "/getOrderDetails",
                type: "get",
                dataType: "JSON",
                data: formData + "&order_id=" + orderId,
                success: function(res){
                    json_text = JSON.stringify(res);
                    obj = JSON.parse(json_text);
                    $("#prodname").val(obj.product_id);
                    $("#orderdate").val(obj.order_date);
                    $("#orderqty").val(obj.order_qty);
                    $("#unit_price").val(obj.unit_price);
                    $("#order_id").val(obj.order_id);
                    // Hide Save button and show Update button
                    $("#btn_save").hide();
                    $("#btn_update").show();
                    
                }
            });
        });
    });
</script>






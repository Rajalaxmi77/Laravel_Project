<!-- editOrder.blade.php -->

<form method="post" action="updateOrder">
    <?php echo csrf_field(); ?>
    
    <label>Order Date:</label>
    <input type="text" name="orderdate" value="<?php echo e($results->order_date); ?>">
    <br>
    <label>Order Quantity:</label>
    <input type="text" name="orderqty" value="<?php echo e($results->order_qty); ?>">
    <br>
    
    <!-- Other fields you want to edit -->

    <input type="submit" name="btn" value="Update">
</form>
<?php /**PATH C:\Users\rajalaxmi.s\Desktop\Laravel_project\ordermanagement4\resources\views/editOrder.blade.php ENDPATH**/ ?>
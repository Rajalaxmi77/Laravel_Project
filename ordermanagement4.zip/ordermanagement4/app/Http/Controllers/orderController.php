<?php

namespace App\Http\Controllers;
use App\Http\controllers\Controller;

use Illuminate\Http\Request;
use DB;

class orderController extends Controller
{
   public function getproduct(Request $request){
    //for displaying products in dropdown
    $sql = DB::table("product_master")->get();
    
    //for displaying table
    $results = DB::table('order_master')
        ->join('product_master', 'order_master.product_id', '=', 'product_master.product_id')
        ->select(
            'order_master.order_date',
            'order_master.order_id',
            'order_master.order_qty',
            'product_master.unit_price',
            'product_master.name',
        )
        ->get();

     return view('order', ['sql' => $sql, 'results' => $results]);
}

    public function getproductprice(Request $request){
        $input = $request->all();
        $res = DB::table('product_master')
            ->select('unit_price','product_qty')
            ->where('product_id', $input['prodname'])
            ->first();
        return response()->json($res);
    }
    public function saveproduct(Request $request){
        $input=$request->all();
        DB::table('order_master')
        ->insert([
            'product_id' => $input['prodname'],
            'order_date' =>$input['orderdate'],
            'order_qty' => $input['orderqty'],
        ]);

        return redirect('orderpage');
    }

  
    function deleteOrder(Request $request)
    {
        $id=$request->order_id;
        //dd($id);
        $orders=DB::table('order_master')->where('order_id', $id)->delete();
        return redirect('orderpage')->with('results', $orders);
    }

    public function getOrderDetails(Request $request){
        $input = $request->all();
        $id=$request->order_id;
        $res = DB::table('order_master')
            ->select('product_id', 'order_date', 'order_qty','order_id')
            ->where('order_id', $id)
            ->first();
        return response()->json($res);
    }

    public function updateOrder(Request $request){
    
    $id=$request->order_id;
    $prodname=$request->prodname;
    //dd($id);
    $product=DB::table('product_master')->where('name',$prodname)->first();
    // if($product){
    //     DB::table('order_master')
    //     ->where('order_id',$id)
    //     ->update([
    //         'order_date'=>$request->orderdate,
    //         'order_qty'=>$request->orderqty,
    //     ]);
    //     return redirect('orderpage');
    // }
}

          
}
